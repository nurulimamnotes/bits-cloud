CREATE TABLE IF NOT EXISTS `areagroupblocktypes` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `arHandle` varchar(255) NOT NULL,
  `gID` int(10) unsigned NOT NULL DEFAULT '0',
  `uID` int(10) unsigned NOT NULL DEFAULT '0',
  `btID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cID`,`arHandle`,`gID`,`uID`,`btID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



CREATE TABLE IF NOT EXISTS `areagroups` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `arHandle` varchar(255) NOT NULL,
  `gID` int(10) unsigned NOT NULL DEFAULT '0',
  `uID` int(10) unsigned NOT NULL DEFAULT '0',
  `agPermissions` varchar(64) NOT NULL,
  PRIMARY KEY (`cID`,`arHandle`,`gID`,`uID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `areas` (
  `arID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `arHandle` varchar(255) NOT NULL,
  `arOverrideCollectionPermissions` tinyint(1) NOT NULL DEFAULT '0',
  `arInheritPermissionsFromAreaOnCID` int(10) unsigned NOT NULL DEFAULT '0',
  `arIsGlobal` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`arID`),
  KEY `arIsGlobal` (`arIsGlobal`),
  KEY `cID` (`cID`),
  KEY `arHandle` (`arHandle`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=54 ;


INSERT INTO `areas` (`arID`, `cID`, `arHandle`, `arOverrideCollectionPermissions`, `arInheritPermissionsFromAreaOnCID`, `arIsGlobal`) VALUES
(1, 96, 'Header', 0, 0, 0),
(2, 96, 'Column 1', 0, 0, 0),
(3, 96, 'Column 2', 0, 0, 0),
(4, 96, 'Column 3', 0, 0, 0),
(5, 96, 'Column 4', 0, 0, 0),
(6, 95, 'Primary', 0, 0, 0),
(7, 95, 'Secondary 1', 0, 0, 0),
(8, 95, 'Secondary 2', 0, 0, 0),
(9, 95, 'Secondary 3', 0, 0, 0),
(10, 95, 'Secondary 4', 0, 0, 0),
(11, 95, 'Secondary 5', 0, 0, 0),
(12, 111, 'Main', 0, 0, 0),
(13, 112, 'Main', 0, 0, 0),
(14, 113, 'Main', 0, 0, 0),
(15, 114, 'Main', 0, 0, 0),
(16, 114, 'Sidebar', 0, 0, 0),
(17, 114, 'Thumbnail Image', 0, 0, 0),
(18, 114, 'Header Image', 0, 0, 0),
(19, 115, 'Header Image', 0, 0, 0),
(20, 116, 'Header Image', 0, 0, 0),
(21, 117, 'Header Image', 0, 0, 0),
(22, 1, 'Header', 0, 0, 0),
(23, 1, 'Sidebar', 0, 0, 0),
(24, 1, 'Main', 0, 0, 0),
(25, 1, 'Header Image', 0, 0, 0),
(26, 118, 'Header', 0, 0, 0),
(27, 118, 'Sidebar', 0, 0, 0),
(28, 118, 'Main', 0, 0, 0),
(29, 118, 'Header Image', 0, 0, 0),
(30, 122, 'Header', 0, 0, 0),
(31, 122, 'Sidebar', 0, 0, 0),
(32, 122, 'Main', 0, 0, 0),
(33, 122, 'Header Image', 0, 0, 0),
(34, 121, 'Header', 0, 0, 0),
(35, 121, 'Sidebar', 0, 0, 0),
(36, 121, 'Main', 0, 0, 0),
(37, 121, 'Header Image', 0, 0, 0),
(38, 120, 'Header', 0, 0, 0),
(39, 120, 'Sidebar', 0, 0, 0),
(40, 120, 'Main', 0, 0, 0),
(41, 120, 'Header Image', 0, 0, 0),
(42, 119, 'Main', 0, 0, 0),
(43, 119, 'Sidebar', 0, 0, 0),
(44, 119, 'Header Image', 0, 0, 0),
(45, 124, 'Header Image', 0, 0, 0),
(46, 124, 'Main', 0, 0, 0),
(47, 124, 'Thumbnail Image', 0, 0, 0),
(48, 124, 'Sidebar', 0, 0, 0),
(49, 123, 'Main', 0, 0, 0),
(50, 123, 'Sidebar', 0, 0, 0),
(51, 123, 'Header Image', 0, 0, 0),
(52, 1, 'Site Name', 0, 0, 1),
(53, 1, 'Header Nav', 0, 0, 1);


CREATE TABLE IF NOT EXISTS `ataddress` (
  `avID` int(10) unsigned NOT NULL DEFAULT '0',
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state_province` varchar(255) DEFAULT NULL,
  `country` varchar(4) DEFAULT NULL,
  `postal_code` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`avID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ataddresscustomcountries` (
  `atAddressCustomCountryID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `akID` int(10) unsigned NOT NULL DEFAULT '0',
  `country` varchar(5) NOT NULL,
  PRIMARY KEY (`atAddressCustomCountryID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;



CREATE TABLE IF NOT EXISTS `ataddresssettings` (
  `akID` int(10) unsigned NOT NULL DEFAULT '0',
  `akHasCustomCountries` int(1) NOT NULL DEFAULT '0',
  `akDefaultCountry` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`akID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



CREATE TABLE IF NOT EXISTS `atboolean` (
  `avID` int(10) unsigned NOT NULL,
  `value` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`avID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



INSERT INTO `atboolean` (`avID`, `value`) VALUES
(11, 1),
(29, 1),
(30, 1),
(31, 1),
(32, 1),
(38, 1),
(67, 1),
(73, 1),
(74, 1),
(75, 1),
(94, 1),
(95, 1),
(96, 1);



CREATE TABLE IF NOT EXISTS `atbooleansettings` (
  `akID` int(10) unsigned NOT NULL,
  `akCheckedByDefault` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`akID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



INSERT INTO `atbooleansettings` (`akID`, `akCheckedByDefault`) VALUES
(4, 0),
(5, 0),
(7, 0),
(8, 0),
(9, 1),
(10, 1);



CREATE TABLE IF NOT EXISTS `atdatetime` (
  `avID` int(10) unsigned NOT NULL,
  `value` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`avID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `atdatetimesettings` (
  `akID` int(10) unsigned NOT NULL,
  `akDateDisplayMode` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`akID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



CREATE TABLE IF NOT EXISTS `atdefault` (
  `avID` int(10) unsigned NOT NULL,
  `value` longtext,
  PRIMARY KEY (`avID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



INSERT INTO `atdefault` (`avID`, `value`) VALUES
(1, 'blog, blogging'),
(2, 'new blog, write blog'),
(3, 'blog drafts,composer'),
(4, 'pages, add page, delete page, copy, move, alias'),
(5, 'pages, add page, delete page, copy, move, alias'),
(6, 'pages, add page, delete page, copy, move, alias'),
(7, 'find page, search page, search, find'),
(8, 'files, add file, delete file, copy, move, alias'),
(9, 'file, file attributes'),
(10, 'files, category, categories'),
(12, 'users, groups, people'),
(13, 'find, search, people'),
(14, 'user, group, people'),
(15, 'user attributes'),
(16, 'new user'),
(17, 'new user group, new group, group'),
(18, 'forms, log, error, email, mysql, exception, survey'),
(19, 'hits, pageviews, visitors, activity'),
(20, 'forms, questions'),
(21, 'survey, questions, quiz'),
(22, 'forms, log, error, email, mysql, exception, survey'),
(23, 'page types, themes, single pages'),
(24, 'new theme, theme, active theme, change theme, template, css'),
(25, 'add theme'),
(26, 'custom theme, change theme, custom css, css'),
(27, 'page type defaults, global block, global area'),
(28, 'page attributes'),
(33, 'add-on, addon, ecommerce, install, discussions, forums, themes, templates, blocks'),
(34, 'update, upgrade'),
(35, 'concrete5.org, my account, marketplace'),
(36, 'buy theme, new theme, marketplace, template'),
(37, 'buy addon, buy add on, buy add-on, purchase addon, purchase add on, purchase add-on, find addon, new addon, marketplace'),
(39, 'website name'),
(40, 'logo, favicon, iphone'),
(41, 'tinymce, content block, fonts, editor'),
(42, 'translate, translation'),
(43, 'timezone'),
(44, 'interface, quick nav, dashboard background, background image'),
(45, 'vanity, pretty url, seo'),
(46, 'traffic, statistics, google analytics, quant'),
(47, 'turn off statistics'),
(48, 'configure search, site search, search option'),
(49, 'cache option, change cache, turn on cache, turn off cache, no cache, page cache, caching'),
(50, 'cache option, turn off cache, no cache, page cache, caching'),
(51, 'index search, reindex search, build sitemap, sitemap.xml, clear old versions, page versions, remove old'),
(52, 'editors, hide site, offline, private, public'),
(53, 'file options, file manager'),
(54, 'security, files, media '),
(55, 'security, users, actions, administrator, admin'),
(56, 'security, lock ip, lock out, block ip'),
(57, 'security, registration'),
(58, 'antispam, block spam, security'),
(59, 'lock site, under construction'),
(60, 'profile'),
(61, 'member profile, member page,community'),
(62, 'signup, new user, community'),
(63, 'smtp, mail settings'),
(64, 'email server, mail settings, mail configuration'),
(65, 'email server, mail settings, mail configuration, private message, message system'),
(66, 'attribute configuration'),
(68, 'overrides, system info, debug, support,help'),
(69, 'errors,exceptions, develop, support, help'),
(70, 'logs, email, error, exceptions'),
(71, 'security, alternate storage, hide files'),
(72, 'upgrade, new version');



CREATE TABLE IF NOT EXISTS `atfile` (
  `avID` int(10) unsigned NOT NULL,
  `fID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`avID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



CREATE TABLE IF NOT EXISTS `atnumber` (
  `avID` int(10) unsigned NOT NULL,
  `value` decimal(14,4) DEFAULT '0.0000',
  PRIMARY KEY (`avID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


INSERT INTO `atnumber` (`avID`, `value`) VALUES
(76, 960.0000),
(77, 212.0000),
(78, 960.0000),
(79, 212.0000),
(80, 960.0000),
(81, 212.0000),
(82, 960.0000),
(83, 212.0000),
(84, 960.0000),
(85, 212.0000),
(86, 960.0000),
(87, 212.0000),
(88, 960.0000),
(89, 212.0000),
(90, 150.0000),
(91, 150.0000);



CREATE TABLE IF NOT EXISTS `atselectoptions` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `akID` int(10) unsigned DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `displayOrder` int(10) unsigned DEFAULT NULL,
  `isEndUserAdded` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;



INSERT INTO `atselectoptions` (`ID`, `akID`, `value`, `displayOrder`, `isEndUserAdded`) VALUES
(1, 13, 'composer', 0, 1),
(2, 13, 'hello', 1, 1),
(3, 13, 'world', 2, 1),
(4, 13, 'first post', 3, 1);


CREATE TABLE IF NOT EXISTS `atselectoptionsselected` (
  `avID` int(10) unsigned NOT NULL,
  `atSelectOptionID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`avID`,`atSelectOptionID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



INSERT INTO `atselectoptionsselected` (`avID`, `atSelectOptionID`) VALUES
(93, 1),
(93, 2),
(93, 3),
(93, 4);



CREATE TABLE IF NOT EXISTS `atselectsettings` (
  `akID` int(10) unsigned NOT NULL,
  `akSelectAllowMultipleValues` tinyint(1) NOT NULL DEFAULT '0',
  `akSelectOptionDisplayOrder` varchar(255) NOT NULL DEFAULT 'display_asc',
  `akSelectAllowOtherValues` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`akID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



INSERT INTO `atselectsettings` (`akID`, `akSelectAllowMultipleValues`, `akSelectOptionDisplayOrder`, `akSelectAllowOtherValues`) VALUES
(13, 1, 'display_asc', 1);


CREATE TABLE IF NOT EXISTS `attextareasettings` (
  `akID` int(10) unsigned NOT NULL DEFAULT '0',
  `akTextareaDisplayMode` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`akID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


INSERT INTO `attextareasettings` (`akID`, `akTextareaDisplayMode`) VALUES
(2, ''),
(3, ''),
(6, '');


CREATE TABLE IF NOT EXISTS `attributekeycategories` (
  `akCategoryID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `akCategoryHandle` varchar(255) NOT NULL,
  `akCategoryAllowSets` smallint(4) NOT NULL DEFAULT '0',
  `pkgID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`akCategoryID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;


INSERT INTO `attributekeycategories` (`akCategoryID`, `akCategoryHandle`, `akCategoryAllowSets`, `pkgID`) VALUES
(1, 'collection', 1, NULL),
(2, 'user', 1, NULL),
(3, 'file', 1, NULL);


CREATE TABLE IF NOT EXISTS `attributekeys` (
  `akID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `akHandle` varchar(255) NOT NULL,
  `akName` varchar(255) NOT NULL,
  `akIsSearchable` tinyint(1) NOT NULL DEFAULT '0',
  `akIsSearchableIndexed` tinyint(1) NOT NULL DEFAULT '0',
  `akIsAutoCreated` tinyint(1) NOT NULL DEFAULT '0',
  `akIsColumnHeader` tinyint(1) NOT NULL DEFAULT '0',
  `akIsEditable` tinyint(1) NOT NULL DEFAULT '0',
  `atID` int(10) unsigned DEFAULT NULL,
  `akCategoryID` int(10) unsigned DEFAULT NULL,
  `pkgID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`akID`),
  UNIQUE KEY `akHandle` (`akHandle`,`akCategoryID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;


INSERT INTO `attributekeys` (`akID`, `akHandle`, `akName`, `akIsSearchable`, `akIsSearchableIndexed`, `akIsAutoCreated`, `akIsColumnHeader`, `akIsEditable`, `atID`, `akCategoryID`, `pkgID`) VALUES
(1, 'meta_title', 'Meta Title', 1, 1, 0, 0, 1, 1, 1, 0),
(2, 'meta_description', 'Meta Description', 1, 1, 0, 0, 1, 2, 1, 0),
(3, 'meta_keywords', 'Meta Keywords', 1, 1, 0, 0, 1, 2, 1, 0),
(4, 'exclude_nav', 'Exclude From Nav', 1, 1, 0, 0, 1, 3, 1, 0),
(5, 'exclude_page_list', 'Exclude From Page List', 1, 1, 0, 0, 1, 3, 1, 0),
(6, 'header_extra_content', 'Header Extra Content', 1, 1, 0, 0, 1, 2, 1, 0),
(7, 'exclude_search_index', 'Exclude From Search Index', 1, 1, 0, 0, 1, 3, 1, 0),
(8, 'exclude_sitemapxml', 'Exclude From sitemap.xml', 1, 1, 0, 0, 1, 3, 1, 0),
(9, 'profile_private_messages_enabled', 'I would like to receive private messages.', 1, 1, 0, 0, 1, 3, 2, 0),
(10, 'profile_private_messages_notification_enabled', 'Send me email notifications when I receive a private message.', 1, 1, 0, 0, 1, 3, 2, 0),
(11, 'width', 'Width', 1, 1, 0, 0, 1, 6, 3, 0),
(12, 'height', 'Height', 1, 1, 0, 0, 1, 6, 3, 0),
(13, 'tags', 'Tags', 1, 1, 0, 0, 1, 8, 1, 0);


CREATE TABLE IF NOT EXISTS `attributesetkeys` (
  `akID` int(10) unsigned NOT NULL DEFAULT '0',
  `asID` int(10) unsigned NOT NULL DEFAULT '0',
  `displayOrder` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`akID`,`asID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


INSERT INTO `attributesetkeys` (`akID`, `asID`, `displayOrder`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(6, 1, 4),
(4, 2, 1),
(5, 2, 2),
(7, 2, 3),
(8, 2, 4);


CREATE TABLE IF NOT EXISTS `attributesets` (
  `asID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asName` varchar(255) DEFAULT NULL,
  `asHandle` varchar(255) NOT NULL,
  `akCategoryID` int(10) unsigned NOT NULL DEFAULT '0',
  `pkgID` int(10) unsigned NOT NULL DEFAULT '0',
  `asIsLocked` int(1) NOT NULL DEFAULT '1',
  `asDisplayOrder` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`asID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;


INSERT INTO `attributesets` (`asID`, `asName`, `asHandle`, `akCategoryID`, `pkgID`, `asIsLocked`, `asDisplayOrder`) VALUES
(1, 'Page Header', 'page_header', 1, 0, 0, 0),
(2, 'Navigation and Indexing', 'navigation', 1, 0, 0, 1);


CREATE TABLE IF NOT EXISTS `attributetypecategories` (
  `atID` int(10) unsigned NOT NULL DEFAULT '0',
  `akCategoryID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`atID`,`akCategoryID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


INSERT INTO `attributetypecategories` (`atID`, `akCategoryID`) VALUES
(1, 1),
(1, 2),
(1, 3),
(2, 1),
(2, 2),
(2, 3),
(3, 1),
(3, 2),
(3, 3),
(4, 1),
(4, 2),
(4, 3),
(5, 1),
(6, 1),
(6, 2),
(6, 3),
(7, 1),
(7, 3),
(8, 1),
(8, 2),
(8, 3),
(9, 2);


CREATE TABLE IF NOT EXISTS `attributetypes` (
  `atID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `atHandle` varchar(255) NOT NULL,
  `atName` varchar(255) NOT NULL,
  `pkgID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`atID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

INSERT INTO `attributetypes` (`atID`, `atHandle`, `atName`, `pkgID`) VALUES
(1, 'text', 'Text', 0),
(2, 'textarea', 'Text Area', 0),
(3, 'boolean', 'Checkbox', 0),
(4, 'date_time', 'Date/Time', 0),
(5, 'image_file', 'Image/File', 0),
(6, 'number', 'Number', 0),
(7, 'rating', 'Rating', 0),
(8, 'select', 'Select', 0),
(9, 'address', 'Address', 0);

CREATE TABLE IF NOT EXISTS `attributevalues` (
  `avID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `akID` int(10) unsigned DEFAULT NULL,
  `avDateAdded` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `uID` int(10) unsigned DEFAULT NULL,
  `atID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`avID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=98 ;

INSERT INTO `attributevalues` (`avID`, `akID`, `avDateAdded`, `uID`, `atID`) VALUES
(1, 3, NOW(), 1, 2),
(2, 3, NOW(), 1, 2),
(3, 3, NOW(), 1, 2),
(4, 3, NOW(), 1, 2),
(5, 3, NOW(), 1, 2),
(6, 3, NOW(), 1, 2),
(7, 3, NOW(), 1, 2),
(8, 3, NOW(), 1, 2),
(9, 3, NOW(), 1, 2),
(10, 3, NOW(), 1, 2),
(11, 4, NOW(), 1, 3),
(12, 3, NOW(), 1, 2),
(13, 3, NOW(), 1, 2),
(14, 3, NOW(), 1, 2),
(15, 3, NOW(), 1, 2),
(16, 3, NOW(), 1, 2),
(17, 3, NOW(), 1, 2),
(18, 3, NOW(), 1, 2),
(19, 3, NOW(), 1, 2),
(20, 3, NOW(), 1, 2),
(21, 3, NOW(), 1, 2),
(22, 3, NOW(), 1, 2),
(23, 3, NOW(), 1, 2),
(24, 3, NOW(), 1, 2),
(25, 3, NOW(), 1, 2),
(26, 3, NOW(), 1, 2),
(27, 3, NOW(), 1, 2),
(28, 3, NOW(), 1, 2),
(29, 4, NOW(), 1, 3),
(30, 7, NOW(), 1, 3),
(31, 4, NOW(), 1, 3),
(32, 4, NOW(), 1, 3),
(33, 3, NOW(), 1, 2),
(34, 3, NOW(), 1, 2),
(35, 3, NOW(), 1, 2),
(36, 3, NOW(), 1, 2),
(37, 3, NOW(), 1, 2),
(38, 4, NOW(), 1, 3),
(39, 3, NOW(), 1, 2),
(40, 3, NOW(), 1, 2),
(41, 3, NOW(), 1, 2),
(42, 3, NOW(), 1, 2),
(43, 3, NOW(), 1, 2),
(44, 3, NOW(), 1, 2),
(45, 3, NOW(), 1, 2),
(46, 3, NOW(), 1, 2),
(47, 3, NOW(), 1, 2),
(48, 3, NOW(), 1, 2),
(49, 3, NOW(), 1, 2),
(50, 3, NOW(), 1, 2),
(51, 3, NOW(), 1, 2),
(52, 3, NOW(), 1, 2),
(53, 3, NOW(), 1, 2),
(54, 3, NOW(), 1, 2),
(55, 3, NOW(), 1, 2),
(56, 3, NOW(), 1, 2),
(57, 3, NOW(), 1, 2),
(58, 3, NOW(), 1, 2),
(59, 3, NOW(), 1, 2),
(60, 3, NOW(), 1, 2),
(61, 3, NOW(), 1, 2),
(62, 3, NOW(), 1, 2),
(63, 3, NOW(), 1, 2),
(64, 3, NOW(), 1, 2),
(65, 3, NOW(), 1, 2),
(66, 3, NOW(), 1, 2),
(67, 7, NOW(), 1, 3),
(68, 3, NOW(), 1, 2),
(69, 3, NOW(), 1, 2),
(70, 3, NOW(), 1, 2),
(71, 3, NOW(), 1, 2),
(72, 3, NOW(), 1, 2),
(73, 4, NOW(), 1, 3),
(74, 4, NOW(), 1, 3),
(75, 7, NOW(), 1, 3),
(76, 11, NOW(), 1, 6),
(77, 12, NOW(), 1, 6),
(78, 11, NOW(), 1, 6),
(79, 12, NOW(), 1, 6),
(80, 11, NOW(), 1, 6),
(81, 12, NOW(), 1, 6),
(82, 11, NOW(), 1, 6),
(83, 12, NOW(), 1, 6),
(84, 11, NOW(), 1, 6),
(85, 12, NOW(), 1, 6),
(86, 11, NOW(), 1, 6),
(87, 12, NOW(), 1, 6),
(88, 11, NOW(), 1, 6),
(89, 12, NOW(), 1, 6),
(90, 11, NOW(), 1, 6),
(91, 12, NOW(), 1, 6),
(92, 13, NOW(), 1, 8),
(93, 13, NOW(), 1, 8),
(94, 4, NOW(), 1, 3),
(95, 5, NOW(), 1, 3),
(96, 7, NOW(), 1, 3),
(97, 13, NOW(), 1, 8);

CREATE TABLE IF NOT EXISTS `blockrelations` (
  `brID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bID` int(10) unsigned NOT NULL DEFAULT '0',
  `originalBID` int(10) unsigned NOT NULL DEFAULT '0',
  `relationType` varchar(50) NOT NULL,
  PRIMARY KEY (`brID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;


CREATE TABLE IF NOT EXISTS `blocks` (
  `bID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bName` varchar(60) DEFAULT NULL,
  `bDateAdded` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `bDateModified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `bFilename` varchar(32) DEFAULT NULL,
  `bIsActive` varchar(1) NOT NULL DEFAULT '1',
  `btID` int(10) unsigned NOT NULL DEFAULT '0',
  `uID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`bID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=53 ;

INSERT INTO `blocks` (`bID`, `bName`, `bDateAdded`, `bDateModified`, `bFilename`, `bIsActive`, `btID`, `uID`) VALUES
(1, '', NOW(), NOW(), NULL, '1', 9, 1),
(2, '', NOW(), NOW(), NULL, '1', 9, 1),
(3, '', NOW(), NOW(), NULL, '1', 9, 1),
(4, '', NOW(), NOW(), NULL, '1', 9, 1),
(5, '', NOW(), NOW(), NULL, '1', 9, 1),
(6, '', NOW(), NOW(), NULL, '1', 6, 1),
(7, '', NOW(), NOW(), NULL, '1', 7, 1),
(8, '', NOW(), NOW(), NULL, '1', 5, 1),
(9, '', NOW(), NOW(), NULL, '1', 5, 1),
(10, '', NOW(), NOW(), NULL, '1', 4, 1),
(11, '', NOW(), NOW(), NULL, '1', 3, 1),
(12, '', NOW(), NOW(), NULL, '1', 5, 1),
(13, 'Blog Content', NOW(), NOW(), NULL, '1', 9, 1),
(14, '', NOW(), NOW(), NULL, '1', 25, 1),
(15, 'Thumbnail Image', NOW(), NOW(), NULL, '1', 18, 1),
(16, 'Header Image', NOW(), NOW(), NULL, '1', 18, 1),
(17, '', NOW(), NOW(), NULL, '1', 18, 1),
(18, '', NOW(), NOW(), NULL, '1', 18, 1),
(19, '', NOW(), NOW(), NULL, '1', 18, 1),
(20, '', NOW(), NOW(), NULL, '1', 8, 1),
(21, '', NOW(), NOW(), NULL, '1', 9, 1),
(22, '', NOW(), NOW(), NULL, '1', 8, 1),
(23, '', NOW(), NOW(), NULL, '1', 9, 1),
(24, '', NOW(), NOW(), NULL, '1', 9, 1),
(25, '', NOW(), NOW(), NULL, '1', 9, 1),
(26, '', NOW(), NOW(), NULL, '1', 9, 1),
(27, '', NOW(), NOW(), NULL, '1', 9, 1),
(28, '', NOW(), NOW(), NULL, '1', 18, 1),
(29, '', NOW(), NOW(), NULL, '1', 9, 1),
(30, '', NOW(), NOW(), NULL, '1', 2, 1),
(31, '', NOW(), NOW(), NULL, '1', 9, 1),
(32, '', NOW(), NOW(), NULL, '1', 9, 1),
(33, '', NOW(), NOW(), NULL, '1', 2, 1),
(34, '', NOW(), NOW(), NULL, '1', 16, 1),
(35, '', NOW(), NOW(), NULL, '1', 9, 1),
(36, '', NOW(), NOW(), NULL, '1', 2, 1),
(37, '', NOW(), NOW(), NULL, '1', 9, 1),
(38, '', NOW(), NOW(), NULL, '1', 14, 1),
(39, '', NOW(), NOW(), NULL, '1', 9, 1),
(40, '', NOW(), NOW(), NULL, '1', 9, 1),
(41, '', NOW(), NOW(), NULL, '1', 8, 1),
(42, '', NOW(), NOW(), NULL, '1', 22, 1),
(43, '', NOW(), NOW(), 'blog_index_thumbnail.php', '1', 20, 1),
(44, '', NOW(), NOW(), NULL, '1', 9, 1),
(45, '', NOW(), NOW(), NULL, '1', 25, 1),
(46, '', NOW(), NOW(), NULL, '1', 28, 1),
(47, 'Header Image', NOW(), NOW(), NULL, '1', 18, 1),
(48, 'Blog Content', NOW(), NOW(), NULL, '1', 9, 1),
(49, 'Thumbnail Image', NOW(), NOW(), NULL, '1', 18, 1),
(50, '', NOW(), NOW(), NULL, '1', 22, 1),
(51, '', NOW(), NOW(), NULL, '1', 25, 1),
(52, '', NOW(), NOW(), NULL, '1', 28, 1);


CREATE TABLE IF NOT EXISTS `blocktypes` (
  `btID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `btHandle` varchar(32) NOT NULL,
  `btName` varchar(128) NOT NULL,
  `btDescription` text,
  `btActiveWhenAdded` tinyint(1) NOT NULL DEFAULT '1',
  `btCopyWhenPropagate` tinyint(1) NOT NULL DEFAULT '0',
  `btIncludeAll` tinyint(1) NOT NULL DEFAULT '0',
  `btIsInternal` tinyint(1) NOT NULL DEFAULT '0',
  `btInterfaceWidth` int(10) unsigned NOT NULL DEFAULT '400',
  `btInterfaceHeight` int(10) unsigned NOT NULL DEFAULT '400',
  `pkgID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`btID`),
  UNIQUE KEY `btHandle` (`btHandle`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=29 ;

INSERT INTO `blocktypes` (`btID`, `btHandle`, `btName`, `btDescription`, `btActiveWhenAdded`, `btCopyWhenPropagate`, `btIncludeAll`, `btIsInternal`, `btInterfaceWidth`, `btInterfaceHeight`, `pkgID`) VALUES
(1, 'core_scrapbook_display', 'Scrapbook Display (Core)', 'Proxy block for blocks pasted through the scrapbook.', 1, 0, 0, 1, 400, 400, 0),
(2, 'core_stack_display', 'Stack Display (Core)', 'Proxy block for stacks added through the UI.', 1, 0, 0, 1, 400, 400, 0),
(3, 'dashboard_featured_addon', 'Dashboard Featured Add-On', 'Features an add-on from concrete5.org.', 1, 0, 0, 1, 300, 100, 0),
(4, 'dashboard_featured_theme', 'Dashboard Featured Theme', 'Features a theme from concrete5.org.', 1, 0, 0, 1, 300, 100, 0),
(5, 'dashboard_newsflow_latest', 'Dashboard Newsflow Latest', 'Grabs the latest newsflow data from concrete5.org.', 1, 0, 0, 1, 400, 400, 0),
(6, 'dashboard_app_status', 'Dashboard App Status', 'Displays update and welcome back information on your dashboard.', 1, 0, 0, 1, 400, 400, 0),
(7, 'dashboard_site_activity', 'Dashboard Site Activity', 'Displays a summary of website activity.', 1, 0, 0, 1, 400, 400, 0),
(8, 'autonav', 'Auto-Nav', 'Creates navigation trees and sitemaps.', 1, 0, 0, 0, 500, 350, 0),
(9, 'content', 'Content', 'HTML/WYSIWYG Editor Content.', 1, 0, 0, 0, 600, 465, 0),
(10, 'date_nav', 'Date Navigation', 'A collapsible date based navigation tree', 1, 0, 0, 0, 500, 350, 0),
(11, 'external_form', 'External Form', 'Include external forms in the filesystem and place them on pages.', 1, 0, 0, 0, 370, 100, 0),
(12, 'file', 'File', 'Link to files stored in the asset library.', 1, 0, 0, 0, 300, 250, 0),
(13, 'flash_content', 'Flash Content', 'Embeds SWF files, including flash detection.', 1, 0, 0, 0, 380, 200, 0),
(14, 'form', 'Form', 'Build simple forms and surveys.', 1, 0, 0, 0, 420, 430, 0),
(15, 'google_map', 'Google Map', 'Enter an address and a Google Map of that location will be placed in your page.', 1, 0, 0, 0, 400, 200, 0),
(16, 'guestbook', 'Guestbook / Comments', 'Adds blog-style comments (a guestbook) to your page.', 1, 0, 1, 0, 350, 460, 0),
(17, 'html', 'HTML', 'For adding HTML by hand.', 1, 0, 0, 0, 600, 465, 0),
(18, 'image', 'Image', 'Adds images and onstates from the library to pages.', 1, 0, 0, 0, 400, 550, 0),
(19, 'next_previous', 'Next & Previous Nav', 'Navigate through sibling pages.', 1, 0, 0, 0, 430, 400, 0),
(20, 'page_list', 'Page List', 'List pages based on type, area.', 1, 0, 0, 0, 500, 350, 0),
(21, 'rss_displayer', 'RSS Displayer', 'Fetch, parse and display the contents of an RSS or Atom feed.', 1, 0, 0, 0, 400, 330, 0),
(22, 'search', 'Search', 'Add a search box to your site.', 1, 0, 0, 0, 400, 240, 0),
(23, 'slideshow', 'Slideshow', 'Display a running loop of images.', 1, 0, 0, 0, 550, 400, 0),
(24, 'survey', 'Survey', 'Provide a simple survey, along with results in a pie chart format.', 1, 0, 1, 0, 420, 300, 0),
(25, 'tags', 'Tags', 'List pages based on type, area.', 1, 0, 0, 0, 450, 260, 0),
(26, 'video', 'Video Player', 'Embeds uploaded video into a web page. Supports AVI, WMV, Quicktime/MPEG4 and FLV formats.', 1, 0, 0, 0, 320, 220, 0),
(27, 'youtube', 'YouTube Video', 'Embeds a YouTube Video in your web page.', 1, 0, 0, 0, 400, 210, 0),
(28, 'date_archive', 'Blog Date Archive', 'Displays month archive for pages', 1, 0, 0, 0, 500, 350, 0);


CREATE TABLE IF NOT EXISTS `btcontentfile` (
  `bID` int(10) unsigned NOT NULL,
  `fID` int(10) unsigned DEFAULT NULL,
  `fileLinkText` varchar(255) DEFAULT NULL,
  `filePassword` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`bID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `btcontentimage` (
  `bID` int(10) unsigned NOT NULL,
  `fID` int(10) unsigned DEFAULT '0',
  `fOnstateID` int(10) unsigned DEFAULT '0',
  `maxWidth` int(10) unsigned DEFAULT '0',
  `maxHeight` int(10) unsigned DEFAULT '0',
  `externalLink` varchar(255) DEFAULT NULL,
  `internalLinkCID` int(10) unsigned DEFAULT '0',
  `forceImageToMatchDimensions` int(10) unsigned DEFAULT '0',
  `altText` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`bID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `btcontentimage` (`bID`, `fID`, `fOnstateID`, `maxWidth`, `maxHeight`, `externalLink`, `internalLinkCID`, `forceImageToMatchDimensions`, `altText`) VALUES
(15, 8, 0, 0, 0, '', 0, NULL, ''),
(16, 2, 0, 960, 212, '', 0, 1, 'My concrete5 Blog'),
(17, 7, 0, 960, 212, '', 0, 1, ''),
(18, 6, 0, 960, 212, '', 0, 1, ''),
(19, 4, 0, 960, 212, '', 0, 1, ''),
(28, 1, 0, 960, 212, '', 0, 1, ''),
(47, 2, 0, 960, 212, '', 0, 1, 'My concrete5 Blog'),
(49, 8, 0, 0, 0, '', 0, NULL, '');

CREATE TABLE IF NOT EXISTS `btcontentlocal` (
  `bID` int(10) unsigned NOT NULL,
  `content` longtext,
  PRIMARY KEY (`bID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `btcontentlocal` (`bID`, `content`) VALUES
(1, '	<div id="newsflow-header-first-run"><h1>Welcome to concrete5.</h1>\n						<h2>It''s easy to edit content and add pages using in-context editing.</h2></div>\n						'),
(2, '<div class="newsflow-column-first-run">\n							<h3>Building Your Own Site</h3>\n							<p>Editing with concrete5 is a breeze. Just point and click to make changes.</p>\n							<br/>\n							<p><a href="javascript:void(0)" onclick="ccm_getNewsflowByPath(''/welcome/editors'')" class="btn primary">Editor''s Guide</a></p>\n							</div>'),
(3, '<div class="newsflow-column-first-run">\n							<h3>Developing Applications</h3>\n							<p>If you�re comfortable in PHP concrete5 should be a breeze to learn. Take a few moments to understand the architecture.</p>\n							<p><a href="javascript:void(0)" onclick="ccm_getNewsflowByPath(''/welcome/developers'')" class="btn primary">Developer''s Guide</a></p>\n							</div>'),
(4, '<div class="newsflow-column-first-run">\n							<h3>Designing Websites</h3>\n							<p>Good with CSS and HTML? You can easily theme anything with concrete5.</p>\n							<br/>\n							<p><a href="javascript:void(0)" onclick="ccm_getNewsflowByPath(''/welcome/designers'')" class="btn primary">Designer''s Guide</a></p>\n							</div>'),
(5, '\n						<div class="newsflow-column-first-run">\n						<h3>Business Background</h3>\n						<p>Worried about license structures, white-labeling or why concrete5 is a good choice for your agency?</p>\n						<p><a href="javascript:void(0)" onclick="ccm_getNewsflowByPath(''/welcome/executives'')" class="btn primary">Executive''s Guide</a></p>\n						</div>'),
(13, '<p>This is my first blog post.</p>'),
(21, '<h3>Links:</h3>'),
(23, '<h1><a title="Home" \n                                	href="{CCM:CID_1}"\n                                >Concrete5</a></h1>'),
(24, '<h1>Welcome to concrete5 - an Open Source CMS</h1>'),
(25, '<h3>Sidebar</h3>'),
(26, '<p>Everything about concrete5 is completely customizable through the CMS. This is a separate area from the main content on the homepage. You can&nbsp;<a title="Move blocks in concrete5" href="http://www.concrete5.org/documentation/general-topics/blocks-and-areas" target="_blank">drag and drop blocks</a>&nbsp;like this around your layout.</p>'),
(27, '<h2>Welcome to concrete5!</h2>\n                                        <p>Content Management is easy with concrete5''s in-context editing. Just <a href="{CCM:CID_100}">login</a> and you can change things as you browse your site.</p>\n                                        <p>You can watch videos and learn how to:</p>\n                                        <ul>\n                                        <li><a title="In-context editing CMS" href="http://www.concrete5.org/documentation/general-topics/in-context-editing/" target="_blank">Edit</a>&nbsp;this page.</li>\n                                        <li>Add a <a title="Add a page in concrete5" href="http://www.concrete5.org/documentation/general-topics/add-a-page/" target="_blank">new page</a>.</li>\n                                        <li>Add some basic functionality, like&nbsp;<a title="Add a simple form in concrete5" href="http://www.concrete5.org/documentation/general-topics/add_a_form" target="_blank">a Form</a>.</li>\n                                        <li><a title="add-on marketplace for concrete5" href="http://www.concrete5.org/marketplace/how_to_install_add_ons_and_themes_/" target="_blank">Finding &amp; adding</a>&nbsp;more functionality and themes.</li>\n                                        </ul>\n                                        <p>We''ve taken the liberty to build out the rest of this site with some sample content that will help you learn concrete5. Wander around a bit, or click Dashboard to get to the&nbsp;<a href="{CCM:CID_6}">Sitemap</a> and quickly delete the parts you don''t want.</p>'),
(29, '<h1>About Us</h1>'),
(31, '<h2>Learn More</h2>\n																<p>Visit&nbsp;<a title="concrete5 Content Management System" href="http://www.concrete5.org/" target="_blank">concrete5.org</a>&nbsp;to learn more from the&nbsp;<a title="open source content management system" href="http://www.concrete5.org/community" target="_blank">community</a>&nbsp;and the&nbsp;<a href="http://www.concrete5.org/documentation/general-topics/" target="_blank">documentation</a>. You can also browse our&nbsp;<a title="concrete5 marketplace" href="http://www.concrete5.org/marketplace/" target="_blank">marketplace</a>&nbsp;for more&nbsp;<a title="Add-ons for concrete5" href="http://www.concrete5.org/marketplace/addons/" target="_blank">add-ons</a>&nbsp;and&nbsp;<a title="Themes for concrete5" href="http://www.concrete5.org/marketplace/themes/" target="_blank">themes</a>&nbsp;to quickly build the site you really need.&nbsp;</p>\n																<h3>&nbsp;</h3>\n																<h3>Getting Help</h3>\n																<p>You can get free help in the <a href="http://www.concrete5.org/community/forums/" target="_blank">forums</a> and post for free to the&nbsp;<a href="http://www.concrete5.org/community/forums/jobs1/" target="_blank">jobs board</a>.&nbsp;</p>\n																<p>You can also pay the concrete5 team of developers to help with&nbsp;<a href="http://www.concrete5.org/services/support/" target="_blank">any problem</a>&nbsp;you run into. We offer <a href="http://www.concrete5.org/services/training/" target="_blank">training courses</a>&nbsp;and&nbsp;<a href="http://www.concrete5.org/services/hosting/" target="_blank">hosting packages</a>, just let us know <a href="http://www.concrete5.org/services/professional_services/" target="_blank">how we can help</a>.</p>'),
(32, '<h1>Guestbook</h1>'),
(35, '<h1>Contact Us</h1>'),
(37, '<h2>Contact Us</h2>\n									<p>Building a form is easy to do. Learn how to <a href="http://www.concrete5.org/documentation/general-topics/add_a_form" target="_blank">add a form block</a>.</p>'),
(39, '<h1>Sitemap</h1>'),
(40, '<h3>Site Map</h3>'),
(44, '<h3>Tags</h3>'),
(48, '<p>Here is some sample content! I''m writing it using composer!</p>');

CREATE TABLE IF NOT EXISTS `btcorescrapbookdisplay` (
  `bID` int(10) unsigned NOT NULL,
  `bOriginalID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`bID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `btcorestackdisplay` (
  `bID` int(10) unsigned NOT NULL,
  `stID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`bID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `btcorestackdisplay` (`bID`, `stID`) VALUES
(30, 112),
(33, 112),
(36, 112);

CREATE TABLE IF NOT EXISTS `btdashboardnewsflowlatest` (
  `bID` int(10) unsigned NOT NULL,
  `slot` varchar(1) NOT NULL,
  PRIMARY KEY (`bID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `btdashboardnewsflowlatest` (`bID`, `slot`) VALUES
(8, 'A'),
(9, 'B'),
(12, 'C');

CREATE TABLE IF NOT EXISTS `btdatearchive` (
  `bID` int(10) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `targetCID` int(11) DEFAULT NULL,
  `numMonths` int(11) DEFAULT '12',
  PRIMARY KEY (`bID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `btdatearchive` (`bID`, `title`, `targetCID`, `numMonths`) VALUES
(46, 'Archives', 123, 12),
(52, 'Archives', 123, 12);

CREATE TABLE IF NOT EXISTS `btdatenav` (
  `bID` int(10) unsigned NOT NULL,
  `num` smallint(5) unsigned NOT NULL,
  `cParentID` int(10) unsigned NOT NULL DEFAULT '1',
  `cThis` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ctID` smallint(5) unsigned DEFAULT NULL,
  `flatDisplay` int(11) DEFAULT '0',
  `defaultNode` varchar(64) DEFAULT 'current_page',
  `truncateTitles` int(11) DEFAULT '0',
  `truncateSummaries` int(11) DEFAULT '0',
  `displayFeaturedOnly` int(11) DEFAULT '0',
  `truncateChars` int(11) DEFAULT '128',
  `truncateTitleChars` int(11) DEFAULT '128',
  `showDescriptions` int(11) DEFAULT '0',
  PRIMARY KEY (`bID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `btexternalform` (
  `bID` int(10) unsigned NOT NULL,
  `filename` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`bID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `btflashcontent` (
  `bID` int(10) unsigned NOT NULL,
  `fID` int(10) unsigned DEFAULT NULL,
  `quality` varchar(255) DEFAULT NULL,
  `minVersion` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`bID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `btform` (
  `bID` int(10) unsigned NOT NULL,
  `questionSetId` int(10) unsigned DEFAULT '0',
  `surveyName` varchar(255) DEFAULT NULL,
  `thankyouMsg` text,
  `notifyMeOnSubmission` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `recipientEmail` varchar(255) DEFAULT NULL,
  `displayCaptcha` int(11) DEFAULT '1',
  `redirectCID` int(11) DEFAULT '0',
  `addFilesToSet` int(11) DEFAULT '0',
  PRIMARY KEY (`bID`),
  KEY `questionSetIdForeign` (`questionSetId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `btform` (`bID`, `questionSetId`, `surveyName`, `thankyouMsg`, `notifyMeOnSubmission`, `recipientEmail`, `displayCaptcha`, `redirectCID`, `addFilesToSet`) VALUES
(38, 1342084591, 'Contact Us', 'Thanks!', 0, '', 0, 0, 0);


CREATE TABLE IF NOT EXISTS `btformanswers` (
  `aID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asID` int(10) unsigned DEFAULT '0',
  `msqID` int(10) unsigned DEFAULT '0',
  `answer` varchar(255) DEFAULT NULL,
  `answerLong` text,
  PRIMARY KEY (`aID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;


CREATE TABLE IF NOT EXISTS `btformanswerset` (
  `asID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `questionSetId` int(10) unsigned DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `uID` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`asID`),
  KEY `questionSetId` (`questionSetId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;


CREATE TABLE IF NOT EXISTS `btformquestions` (
  `qID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `msqID` int(10) unsigned DEFAULT '0',
  `bID` int(10) unsigned DEFAULT '0',
  `questionSetId` int(10) unsigned DEFAULT '0',
  `question` varchar(255) DEFAULT NULL,
  `inputType` varchar(255) DEFAULT NULL,
  `options` text,
  `position` int(10) unsigned DEFAULT '1000',
  `width` int(10) unsigned DEFAULT '50',
  `height` int(10) unsigned DEFAULT '3',
  `required` int(11) DEFAULT '0',
  PRIMARY KEY (`qID`),
  KEY `questionSetId` (`questionSetId`),
  KEY `msqID` (`msqID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;


INSERT INTO `btformquestions` (`qID`, `msqID`, `bID`, `questionSetId`, `question`, `inputType`, `options`, `position`, `width`, `height`, `required`) VALUES
(5, 4, 38, 1342084591, 'Name', 'field', '', 0, 50, 3, 1),
(6, 5, 38, 1342084591, 'Email:', 'email', '', 0, 50, 3, 1),
(7, 6, 38, 1342084591, 'What are you contacting us about?', 'radios', 'Question%%Comment%%Urgent Issue%%To Say Hello%%Other', 0, 50, 3, 1),
(8, 7, 38, 1342084591, 'Message', 'text', '', 0, 50, 3, 1);

CREATE TABLE IF NOT EXISTS `btgooglemap` (
  `bID` int(10) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `zoom` int(8) DEFAULT NULL,
  PRIMARY KEY (`bID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `btguestbook` (
  `bID` int(10) unsigned NOT NULL,
  `requireApproval` int(11) DEFAULT '0',
  `title` varchar(100) DEFAULT 'Comments',
  `dateFormat` varchar(100) DEFAULT NULL,
  `displayGuestBookForm` int(11) DEFAULT '1',
  `displayCaptcha` int(11) DEFAULT '1',
  `authenticationRequired` int(11) DEFAULT '0',
  `notifyEmail` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`bID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `btguestbook` (`bID`, `requireApproval`, `title`, `dateFormat`, `displayGuestBookForm`, `displayCaptcha`, `authenticationRequired`, `notifyEmail`) VALUES
(34, 0, 'Tell us what you think', 'M jS, Y', 1, 1, 0, '');


CREATE TABLE IF NOT EXISTS `btguestbookentries` (
  `bID` int(11) DEFAULT NULL,
  `cID` int(11) DEFAULT '1',
  `entryID` int(11) NOT NULL AUTO_INCREMENT,
  `uID` int(11) DEFAULT '0',
  `commentText` longtext,
  `user_name` varchar(100) DEFAULT NULL,
  `user_email` varchar(100) DEFAULT NULL,
  `entryDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `approved` int(11) DEFAULT '1',
  PRIMARY KEY (`entryID`),
  KEY `cID` (`cID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `btnavigation` (
  `bID` int(10) unsigned NOT NULL,
  `orderBy` varchar(255) DEFAULT 'alpha_asc',
  `displayPages` varchar(255) DEFAULT 'top',
  `displayPagesCID` int(10) unsigned NOT NULL DEFAULT '1',
  `displayPagesIncludeSelf` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `displaySubPages` varchar(255) DEFAULT 'none',
  `displaySubPageLevels` varchar(255) DEFAULT 'none',
  `displaySubPageLevelsNum` smallint(5) unsigned NOT NULL DEFAULT '0',
  `displayUnavailablePages` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`bID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `btnavigation` (`bID`, `orderBy`, `displayPages`, `displayPagesCID`, `displayPagesIncludeSelf`, `displaySubPages`, `displaySubPageLevels`, `displaySubPageLevelsNum`, `displayUnavailablePages`) VALUES
(20, 'display_asc', 'top', 0, 0, 'none', 'enough', 0, 0),
(22, 'display_asc', 'second_level', 0, 0, 'all', 'all', 0, 0),
(41, 'display_asc', 'top', 0, 0, 'all', 'all', 0, 0);

CREATE TABLE IF NOT EXISTS `btnextprevious` (
  `bID` int(10) unsigned NOT NULL,
  `linkStyle` varchar(32) DEFAULT NULL,
  `nextLabel` varchar(128) DEFAULT NULL,
  `previousLabel` varchar(128) DEFAULT NULL,
  `parentLabel` varchar(128) DEFAULT NULL,
  `showArrows` int(11) DEFAULT '1',
  `loopSequence` int(11) DEFAULT '1',
  `excludeSystemPages` int(11) DEFAULT '1',
  `orderBy` varchar(20) DEFAULT 'display_asc',
  PRIMARY KEY (`bID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `btpagelist` (
  `bID` int(10) unsigned NOT NULL,
  `num` smallint(5) unsigned NOT NULL,
  `orderBy` varchar(32) DEFAULT NULL,
  `cParentID` int(10) unsigned NOT NULL DEFAULT '1',
  `cThis` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `includeAllDescendents` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `paginate` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `displayAliases` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `ctID` smallint(5) unsigned DEFAULT NULL,
  `rss` int(11) DEFAULT '0',
  `rssTitle` varchar(255) DEFAULT NULL,
  `rssDescription` longtext,
  `truncateSummaries` int(11) DEFAULT '0',
  `displayFeaturedOnly` int(11) DEFAULT '0',
  `truncateChars` int(11) DEFAULT '128',
  PRIMARY KEY (`bID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


INSERT INTO `btpagelist` (`bID`, `num`, `orderBy`, `cParentID`, `cThis`, `includeAllDescendents`, `paginate`, `displayAliases`, `ctID`, `rss`, `rssTitle`, `rssDescription`, `truncateSummaries`, `displayFeaturedOnly`, `truncateChars`) VALUES
(43, 12, 'chrono_desc', 119, 0, 0, 1, 0, 4, 0, '', '', 1, 0, 128);

CREATE TABLE IF NOT EXISTS `btrssdisplay` (
  `bID` int(10) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `dateFormat` varchar(100) DEFAULT NULL,
  `itemsToDisplay` int(10) unsigned DEFAULT '5',
  `showSummary` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `launchInNewWindow` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`bID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `btsearch` (
  `bID` int(10) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `buttonText` varchar(128) DEFAULT NULL,
  `baseSearchPath` varchar(255) DEFAULT NULL,
  `resultsURL` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`bID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `btsearch` (`bID`, `title`, `buttonText`, `baseSearchPath`, `resultsURL`) VALUES
(42, 'Search This Site', 'Search', '', ''),
(50, 'Search Blog', 'Search', '/blog', '');

CREATE TABLE IF NOT EXISTS `btslideshow` (
  `bID` int(10) unsigned NOT NULL,
  `fsID` int(10) unsigned DEFAULT NULL,
  `playback` varchar(50) DEFAULT NULL,
  `duration` int(10) unsigned DEFAULT NULL,
  `fadeDuration` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`bID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `btslideshowimg` (
  `slideshowImgId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bID` int(10) unsigned DEFAULT NULL,
  `fID` int(10) unsigned DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `duration` int(10) unsigned DEFAULT NULL,
  `fadeDuration` int(10) unsigned DEFAULT NULL,
  `groupSet` int(10) unsigned DEFAULT NULL,
  `position` int(10) unsigned DEFAULT NULL,
  `imgHeight` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`slideshowImgId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `btsurvey` (
  `bID` int(10) unsigned NOT NULL,
  `question` varchar(255) DEFAULT '',
  `requiresRegistration` int(11) DEFAULT '0',
  PRIMARY KEY (`bID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `btsurveyoptions` (
  `optionID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bID` int(11) DEFAULT NULL,
  `optionName` varchar(255) DEFAULT NULL,
  `displayOrder` int(11) DEFAULT '0',
  PRIMARY KEY (`optionID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `btsurveyresults` (
  `resultID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `optionID` int(10) unsigned DEFAULT '0',
  `uID` int(10) unsigned DEFAULT '0',
  `bID` int(11) DEFAULT NULL,
  `cID` int(11) DEFAULT NULL,
  `ipAddress` varchar(128) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`resultID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;


CREATE TABLE IF NOT EXISTS `bttags` (
  `bID` int(10) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `targetCID` int(11) DEFAULT NULL,
  `displayMode` varchar(20) DEFAULT 'page',
  `cloudCount` int(11) DEFAULT '10',
  PRIMARY KEY (`bID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


INSERT INTO `bttags` (`bID`, `title`, `targetCID`, `displayMode`, `cloudCount`) VALUES
(14, 'Tags', 123, 'page', 0),
(45, '', 123, 'cloud', 0),
(51, 'Tags', 123, 'cloud', 0);

CREATE TABLE IF NOT EXISTS `btvideo` (
  `bID` int(10) unsigned NOT NULL,
  `fID` int(10) unsigned DEFAULT NULL,
  `width` int(10) unsigned DEFAULT NULL,
  `height` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`bID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `btyoutube` (
  `bID` int(10) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `videoURL` varchar(255) DEFAULT NULL,
  `vHeight` varchar(255) DEFAULT NULL,
  `vWidth` varchar(255) DEFAULT NULL,
  `vPlayer` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`bID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `collectionattributevalues` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `cvID` int(10) unsigned NOT NULL DEFAULT '0',
  `akID` int(10) unsigned NOT NULL DEFAULT '0',
  `avID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cID`,`cvID`,`akID`,`avID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


INSERT INTO `collectionattributevalues` (`cID`, `cvID`, `akID`, `avID`) VALUES
(3, 1, 3, 1),
(4, 1, 3, 2),
(5, 1, 3, 3),
(6, 1, 3, 4),
(7, 1, 3, 5),
(8, 1, 3, 6),
(9, 1, 3, 7),
(11, 1, 3, 8),
(12, 1, 3, 9),
(13, 1, 3, 10),
(14, 1, 4, 11),
(15, 1, 3, 12),
(16, 1, 3, 13),
(17, 1, 3, 14),
(18, 1, 3, 15),
(19, 1, 3, 16),
(20, 1, 3, 17),
(21, 1, 3, 18),
(22, 1, 3, 19),
(23, 1, 3, 20),
(24, 1, 3, 21),
(25, 1, 3, 22),
(26, 1, 3, 23),
(27, 1, 3, 24),
(28, 1, 3, 25),
(30, 1, 3, 26),
(31, 1, 3, 27),
(33, 1, 3, 28),
(37, 1, 4, 29),
(37, 1, 7, 30),
(39, 1, 4, 31),
(40, 1, 4, 32),
(41, 1, 3, 33),
(42, 1, 3, 34),
(43, 1, 3, 35),
(44, 1, 3, 36),
(45, 1, 3, 37),
(46, 1, 4, 38),
(48, 1, 3, 39),
(49, 1, 3, 40),
(50, 1, 3, 41),
(51, 1, 3, 42),
(52, 1, 3, 43),
(53, 1, 3, 44),
(55, 1, 3, 45),
(56, 1, 3, 46),
(57, 1, 3, 47),
(58, 1, 3, 48),
(60, 1, 3, 49),
(61, 1, 3, 50),
(62, 1, 3, 51),
(64, 1, 3, 52),
(65, 1, 3, 53),
(66, 1, 3, 54),
(67, 1, 3, 55),
(68, 1, 3, 56),
(69, 1, 3, 57),
(70, 1, 3, 58),
(71, 1, 3, 59),
(73, 1, 3, 60),
(74, 1, 3, 61),
(75, 1, 3, 62),
(76, 1, 3, 63),
(77, 1, 3, 64),
(78, 1, 3, 65),
(79, 1, 3, 66),
(82, 1, 7, 67),
(83, 1, 3, 68),
(84, 1, 3, 69),
(85, 1, 3, 70),
(86, 1, 3, 71),
(89, 1, 3, 72),
(95, 1, 4, 74),
(95, 1, 7, 75),
(96, 1, 4, 73),
(119, 1, 13, 92),
(123, 1, 4, 94),
(123, 1, 5, 95),
(123, 1, 7, 96),
(123, 1, 13, 97),
(124, 1, 13, 93);

CREATE TABLE IF NOT EXISTS `collections` (
  `cID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cDateAdded` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `cDateModified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `cHandle` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`cID`),
  KEY `cDateModified` (`cDateModified`),
  KEY `cDateAdded` (`cDateAdded`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=125 ;

INSERT INTO `collections` (`cID`, `cDateAdded`, `cDateModified`, `cHandle`) VALUES
(1, NOW(), NOW(), 'home'),
(2, NOW(), NOW(), 'dashboard'),
(3, NOW(), NOW(), 'composer'),
(4, NOW(), NOW(), 'write'),
(5, NOW(), NOW(), 'drafts'),
(6, NOW(), NOW(), 'sitemap'),
(7, NOW(), NOW(), 'full'),
(8, NOW(), NOW(), 'explore'),
(9, NOW(), NOW(), 'search'),
(10, NOW(), NOW(), 'files'),
(11, NOW(), NOW(), 'search'),
(12, NOW(), NOW(), 'attributes'),
(13, NOW(), NOW(), 'sets'),
(14, NOW(), NOW(), 'add_set'),
(15, NOW(), NOW(), 'users'),
(16, NOW(), NOW(), 'search'),
(17, NOW(), NOW(), 'groups'),
(18, NOW(), NOW(), 'attributes'),
(19, NOW(), NOW(), 'add'),
(20, NOW(), NOW(), 'add_group'),
(21, NOW(), NOW(), 'reports'),
(22, NOW(), NOW(), 'statistics'),
(23, NOW(), NOW(), 'forms'),
(24, NOW(), NOW(), 'surveys'),
(25, NOW(), NOW(), 'logs'),
(26, NOW(), NOW(), 'pages'),
(27, NOW(), NOW(), 'themes'),
(28, NOW(), NOW(), 'add'),
(29, NOW(), NOW(), 'inspect'),
(30, NOW(), NOW(), 'customize'),
(31, NOW(), NOW(), 'types'),
(32, NOW(), NOW(), 'add'),
(33, NOW(), NOW(), 'attributes'),
(34, NOW(), NOW(), 'single'),
(35, NOW(), NOW(), 'blocks'),
(36, NOW(), NOW(), 'stacks'),
(37, NOW(), NOW(), 'list'),
(38, NOW(), NOW(), 'types'),
(39, NOW(), NOW(), 'extend'),
(40, NOW(), NOW(), 'news'),
(41, NOW(), NOW(), 'install'),
(42, NOW(), NOW(), 'update'),
(43, NOW(), NOW(), 'connect'),
(44, NOW(), NOW(), 'themes'),
(45, NOW(), NOW(), 'add-ons'),
(46, NOW(), NOW(), 'system'),
(47, NOW(), NOW(), 'basics'),
(48, NOW(), NOW(), 'site_name'),
(49, NOW(), NOW(), 'icons'),
(50, NOW(), NOW(), 'editor'),
(51, NOW(), NOW(), 'multilingual'),
(52, NOW(), NOW(), 'timezone'),
(53, NOW(), NOW(), 'interface'),
(54, NOW(), NOW(), 'seo'),
(55, NOW(), NOW(), 'urls'),
(56, NOW(), NOW(), 'tracking_codes'),
(57, NOW(), NOW(), 'statistics'),
(58, NOW(), NOW(), 'search_index'),
(59, NOW(), NOW(), 'optimization'),
(60, NOW(), NOW(), 'cache'),
(61, NOW(), NOW(), 'clear_cache'),
(62, NOW(), NOW(), 'jobs'),
(63, NOW(), NOW(), 'permissions'),
(64, NOW(), NOW(), 'site'),
(65, NOW(), NOW(), 'files'),
(66, NOW(), NOW(), 'file_types'),
(67, NOW(), NOW(), 'tasks'),
(68, NOW(), NOW(), 'ip_blacklist'),
(69, NOW(), NOW(), 'captcha'),
(70, NOW(), NOW(), 'antispam'),
(71, NOW(), NOW(), 'maintenance_mode'),
(72, NOW(), NOW(), 'registration'),
(73, NOW(), NOW(), 'postlogin'),
(74, NOW(), NOW(), 'profiles'),
(75, NOW(), NOW(), 'public_registration'),
(76, NOW(), NOW(), 'mail'),
(77, NOW(), NOW(), 'method'),
(78, NOW(), NOW(), 'importers'),
(79, NOW(), NOW(), 'attributes'),
(80, NOW(), NOW(), 'sets'),
(81, NOW(), NOW(), 'types'),
(82, NOW(), NOW(), 'environment'),
(83, NOW(), NOW(), 'info'),
(84, NOW(), NOW(), 'debug'),
(85, NOW(), NOW(), 'logging'),
(86, NOW(), NOW(), 'file_storage_locations'),
(87, NOW(), NOW(), 'backup_restore'),
(88, NOW(), NOW(), 'backup'),
(89, NOW(), NOW(), 'update'),
(90, NOW(), NOW(), 'database'),
(91, NOW(), NOW(), 'composer'),
(92, NOW(), NOW(), NULL),
(93, NOW(), NOW(), NULL),
(94, NOW(), NOW(), NULL),
(95, NOW(), NOW(), 'home'),
(96, NOW(), NOW(), 'welcome'),
(97, NOW(), NOW(), '!drafts'),
(98, NOW(), NOW(), '!trash'),
(99, NOW(), NOW(), '!stacks'),
(100, NOW(), NOW(), 'login'),
(101, NOW(), NOW(), 'register'),
(102, NOW(), NOW(), 'profile'),
(103, NOW(), NOW(), 'edit'),
(104, NOW(), NOW(), 'avatar'),
(105, NOW(), NOW(), 'messages'),
(106, NOW(), NOW(), 'friends'),
(107, NOW(), NOW(), 'page_not_found'),
(108, NOW(), NOW(), 'page_forbidden'),
(109, NOW(), NOW(), 'download_file'),
(110, NOW(), NOW(), 'members'),
(111, NOW(), NOW(), 'header-nav'),
(112, NOW(), NOW(), 'side-nav'),
(113, NOW(), NOW(), 'site-name'),
(114, NOW(), NOW(), NULL),
(115, NOW(), NOW(), NULL),
(116, NOW(), NOW(), NULL),
(117, NOW(), NOW(), NULL),
(118, NOW(), NOW(), 'about'),
(119, NOW(), NOW(), 'blog'),
(120, NOW(), NOW(), 'search'),
(121, NOW(), NOW(), 'contact-us'),
(122, NOW(), NOW(), 'guestbook'),
(123, NOW(), NOW(), 'blog-archives'),
(124, NOW(), NOW(), 'hello-world');


CREATE TABLE IF NOT EXISTS `collectionsearchindexattributes` (
  `cID` int(11) unsigned NOT NULL DEFAULT '0',
  `ak_meta_title` text,
  `ak_meta_description` text,
  `ak_meta_keywords` text,
  `ak_exclude_nav` tinyint(4) DEFAULT '0',
  `ak_exclude_page_list` tinyint(4) DEFAULT '0',
  `ak_header_extra_content` text,
  `ak_exclude_search_index` tinyint(4) DEFAULT '0',
  `ak_exclude_sitemapxml` tinyint(4) DEFAULT '0',
  `ak_tags` text,
  PRIMARY KEY (`cID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


INSERT INTO `collectionsearchindexattributes` (`cID`, `ak_meta_title`, `ak_meta_description`, `ak_meta_keywords`, `ak_exclude_nav`, `ak_exclude_page_list`, `ak_header_extra_content`, `ak_exclude_search_index`, `ak_exclude_sitemapxml`, `ak_tags`) VALUES
(3, NULL, NULL, 'blog, blogging', 0, 0, NULL, 0, 0, NULL),
(4, NULL, NULL, 'new blog, write blog', 0, 0, NULL, 0, 0, NULL),
(5, NULL, NULL, 'blog drafts,composer', 0, 0, NULL, 0, 0, NULL),
(6, NULL, NULL, 'pages, add page, delete page, copy, move, alias', 0, 0, NULL, 0, 0, NULL),
(7, NULL, NULL, 'pages, add page, delete page, copy, move, alias', 0, 0, NULL, 0, 0, NULL),
(8, NULL, NULL, 'pages, add page, delete page, copy, move, alias', 0, 0, NULL, 0, 0, NULL),
(9, NULL, NULL, 'find page, search page, search, find', 0, 0, NULL, 0, 0, NULL),
(11, NULL, NULL, 'files, add file, delete file, copy, move, alias', 0, 0, NULL, 0, 0, NULL),
(12, NULL, NULL, 'file, file attributes', 0, 0, NULL, 0, 0, NULL),
(13, NULL, NULL, 'files, category, categories', 0, 0, NULL, 0, 0, NULL),
(14, NULL, NULL, NULL, 1, 0, NULL, 0, 0, NULL),
(15, NULL, NULL, 'users, groups, people', 0, 0, NULL, 0, 0, NULL),
(16, NULL, NULL, 'find, search, people', 0, 0, NULL, 0, 0, NULL),
(17, NULL, NULL, 'user, group, people', 0, 0, NULL, 0, 0, NULL),
(18, NULL, NULL, 'user attributes', 0, 0, NULL, 0, 0, NULL),
(19, NULL, NULL, 'new user', 0, 0, NULL, 0, 0, NULL),
(20, NULL, NULL, 'new user group, new group, group', 0, 0, NULL, 0, 0, NULL),
(21, NULL, NULL, 'forms, log, error, email, mysql, exception, survey', 0, 0, NULL, 0, 0, NULL),
(22, NULL, NULL, 'hits, pageviews, visitors, activity', 0, 0, NULL, 0, 0, NULL),
(23, NULL, NULL, 'forms, questions', 0, 0, NULL, 0, 0, NULL),
(24, NULL, NULL, 'survey, questions, quiz', 0, 0, NULL, 0, 0, NULL),
(25, NULL, NULL, 'forms, log, error, email, mysql, exception, survey', 0, 0, NULL, 0, 0, NULL),
(26, NULL, NULL, 'page types, themes, single pages', 0, 0, NULL, 0, 0, NULL),
(27, NULL, NULL, 'new theme, theme, active theme, change theme, template, css', 0, 0, NULL, 0, 0, NULL),
(28, NULL, NULL, 'add theme', 0, 0, NULL, 0, 0, NULL),
(30, NULL, NULL, 'custom theme, change theme, custom css, css', 0, 0, NULL, 0, 0, NULL),
(31, NULL, NULL, 'page type defaults, global block, global area', 0, 0, NULL, 0, 0, NULL),
(33, NULL, NULL, 'page attributes', 0, 0, NULL, 0, 0, NULL),
(37, NULL, NULL, NULL, 1, 0, NULL, 1, 0, NULL),
(39, NULL, NULL, NULL, 1, 0, NULL, 0, 0, NULL),
(40, NULL, NULL, NULL, 1, 0, NULL, 0, 0, NULL),
(41, NULL, NULL, 'add-on, addon, ecommerce, install, discussions, forums, themes, templates, blocks', 0, 0, NULL, 0, 0, NULL),
(42, NULL, NULL, 'update, upgrade', 0, 0, NULL, 0, 0, NULL),
(43, NULL, NULL, 'concrete5.org, my account, marketplace', 0, 0, NULL, 0, 0, NULL),
(44, NULL, NULL, 'buy theme, new theme, marketplace, template', 0, 0, NULL, 0, 0, NULL),
(45, NULL, NULL, 'buy addon, buy add on, buy add-on, purchase addon, purchase add on, purchase add-on, find addon, new addon, marketplace', 0, 0, NULL, 0, 0, NULL),
(46, NULL, NULL, NULL, 1, 0, NULL, 0, 0, NULL),
(48, NULL, NULL, 'website name', 0, 0, NULL, 0, 0, NULL),
(49, NULL, NULL, 'logo, favicon, iphone', 0, 0, NULL, 0, 0, NULL),
(50, NULL, NULL, 'tinymce, content block, fonts, editor', 0, 0, NULL, 0, 0, NULL),
(51, NULL, NULL, 'translate, translation', 0, 0, NULL, 0, 0, NULL),
(52, NULL, NULL, 'timezone', 0, 0, NULL, 0, 0, NULL),
(53, NULL, NULL, 'interface, quick nav, dashboard background, background image', 0, 0, NULL, 0, 0, NULL),
(55, NULL, NULL, 'vanity, pretty url, seo', 0, 0, NULL, 0, 0, NULL),
(56, NULL, NULL, 'traffic, statistics, google analytics, quant', 0, 0, NULL, 0, 0, NULL),
(57, NULL, NULL, 'turn off statistics', 0, 0, NULL, 0, 0, NULL),
(58, NULL, NULL, 'configure search, site search, search option', 0, 0, NULL, 0, 0, NULL),
(60, NULL, NULL, 'cache option, change cache, turn on cache, turn off cache, no cache, page cache, caching', 0, 0, NULL, 0, 0, NULL),
(61, NULL, NULL, 'cache option, turn off cache, no cache, page cache, caching', 0, 0, NULL, 0, 0, NULL),
(62, NULL, NULL, 'index search, reindex search, build sitemap, sitemap.xml, clear old versions, page versions, remove old', 0, 0, NULL, 0, 0, NULL),
(64, NULL, NULL, 'editors, hide site, offline, private, public', 0, 0, NULL, 0, 0, NULL),
(65, NULL, NULL, 'file options, file manager', 0, 0, NULL, 0, 0, NULL),
(66, NULL, NULL, 'security, files, media ', 0, 0, NULL, 0, 0, NULL),
(67, NULL, NULL, 'security, users, actions, administrator, admin', 0, 0, NULL, 0, 0, NULL),
(68, NULL, NULL, 'security, lock ip, lock out, block ip', 0, 0, NULL, 0, 0, NULL),
(69, NULL, NULL, 'security, registration', 0, 0, NULL, 0, 0, NULL),
(70, NULL, NULL, 'antispam, block spam, security', 0, 0, NULL, 0, 0, NULL),
(71, NULL, NULL, 'lock site, under construction', 0, 0, NULL, 0, 0, NULL),
(73, NULL, NULL, 'profile', 0, 0, NULL, 0, 0, NULL),
(74, NULL, NULL, 'member profile, member page,community', 0, 0, NULL, 0, 0, NULL),
(75, NULL, NULL, 'signup, new user, community', 0, 0, NULL, 0, 0, NULL),
(76, NULL, NULL, 'smtp, mail settings', 0, 0, NULL, 0, 0, NULL),
(77, NULL, NULL, 'email server, mail settings, mail configuration', 0, 0, NULL, 0, 0, NULL),
(78, NULL, NULL, 'email server, mail settings, mail configuration, private message, message system', 0, 0, NULL, 0, 0, NULL),
(79, NULL, NULL, 'attribute configuration', 0, 0, NULL, 0, 0, NULL),
(82, NULL, NULL, NULL, 0, 0, NULL, 1, 0, NULL),
(83, NULL, NULL, 'overrides, system info, debug, support,help', 0, 0, NULL, 0, 0, NULL),
(84, NULL, NULL, 'errors,exceptions, develop, support, help', 0, 0, NULL, 0, 0, NULL),
(85, NULL, NULL, 'logs, email, error, exceptions', 0, 0, NULL, 0, 0, NULL),
(86, NULL, NULL, 'security, alternate storage, hide files', 0, 0, NULL, 0, 0, NULL),
(89, NULL, NULL, 'upgrade, new version', 0, 0, NULL, 0, 0, NULL),
(96, NULL, NULL, NULL, 1, 0, NULL, 0, 0, NULL),
(95, NULL, NULL, NULL, 1, 0, NULL, 1, 0, NULL),
(1, NULL, NULL, NULL, 0, 0, NULL, 0, 0, NULL),
(118, NULL, NULL, NULL, 0, 0, NULL, 0, 0, NULL),
(122, NULL, NULL, NULL, 0, 0, NULL, 0, 0, NULL),
(121, NULL, NULL, NULL, 0, 0, NULL, 0, 0, NULL),
(120, NULL, NULL, NULL, 0, 0, NULL, 0, 0, NULL),
(119, NULL, NULL, NULL, 0, 0, NULL, 0, 0, '\n'),
(124, NULL, NULL, NULL, 0, 0, NULL, 0, 0, '\ncomposer\nhello\nworld\nfirst post\n'),
(123, NULL, NULL, NULL, 1, 1, NULL, 1, 0, '\n');

CREATE TABLE IF NOT EXISTS `collectionversionarealayouts` (
  `cvalID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cID` int(10) unsigned DEFAULT '0',
  `cvID` int(10) unsigned DEFAULT '0',
  `arHandle` varchar(255) DEFAULT NULL,
  `layoutID` int(10) unsigned NOT NULL DEFAULT '0',
  `position` int(10) DEFAULT '1000',
  `areaNameNumber` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`cvalID`),
  KEY `areaLayoutsIndex` (`cID`,`cvID`,`arHandle`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `collectionversionareastyles` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `cvID` int(10) unsigned NOT NULL DEFAULT '0',
  `arHandle` varchar(255) NOT NULL,
  `csrID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cID`,`cvID`,`arHandle`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `collectionversionblockpermissions` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `cvID` int(10) unsigned NOT NULL DEFAULT '1',
  `bID` int(10) unsigned NOT NULL DEFAULT '0',
  `gID` int(10) unsigned NOT NULL DEFAULT '0',
  `uID` int(10) unsigned NOT NULL DEFAULT '0',
  `cbgPermissions` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`cID`,`cvID`,`bID`,`gID`,`uID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `collectionversionblocks` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `cvID` int(10) unsigned NOT NULL DEFAULT '1',
  `bID` int(10) unsigned NOT NULL DEFAULT '0',
  `arHandle` varchar(255) NOT NULL,
  `cbDisplayOrder` int(10) unsigned NOT NULL DEFAULT '0',
  `isOriginal` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `cbOverrideAreaPermissions` tinyint(1) NOT NULL DEFAULT '0',
  `cbIncludeAll` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cID`,`cvID`,`bID`,`arHandle`),
  KEY `cbIncludeAll` (`cbIncludeAll`),
  KEY `isOriginal` (`isOriginal`),
  KEY `bID` (`bID`),
  KEY `cIDcvID` (`cID`,`cvID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


INSERT INTO `collectionversionblocks` (`cID`, `cvID`, `bID`, `arHandle`, `cbDisplayOrder`, `isOriginal`, `cbOverrideAreaPermissions`, `cbIncludeAll`) VALUES
(96, 1, 1, 'Header', 0, 1, 0, 0),
(96, 1, 2, 'Column 1', 0, 1, 0, 0),
(96, 1, 3, 'Column 2', 0, 1, 0, 0),
(96, 1, 4, 'Column 3', 0, 1, 0, 0),
(96, 1, 5, 'Column 4', 0, 1, 0, 0),
(95, 1, 6, 'Primary', 0, 1, 0, 0),
(95, 1, 7, 'Primary', 1, 1, 0, 0),
(95, 1, 8, 'Secondary 1', 0, 1, 0, 0),
(95, 1, 9, 'Secondary 2', 0, 1, 0, 0),
(95, 1, 10, 'Secondary 3', 0, 1, 0, 0),
(95, 1, 11, 'Secondary 4', 0, 1, 0, 0),
(95, 1, 12, 'Secondary 5', 0, 1, 0, 0),
(114, 1, 13, 'Main', 0, 1, 0, 0),
(114, 1, 14, 'Sidebar', 0, 1, 0, 0),
(114, 1, 15, 'Thumbnail Image', 0, 1, 0, 0),
(114, 1, 16, 'Header Image', 0, 1, 0, 0),
(115, 1, 17, 'Header Image', 0, 1, 0, 0),
(116, 1, 18, 'Header Image', 0, 1, 0, 0),
(117, 1, 19, 'Header Image', 0, 1, 0, 0),
(111, 1, 20, 'Main', 0, 1, 0, 0),
(112, 1, 21, 'Main', 0, 1, 0, 0),
(112, 1, 22, 'Main', 1, 1, 0, 0),
(113, 1, 23, 'Main', 0, 1, 0, 0),
(1, 1, 24, 'Header', 0, 1, 0, 0),
(1, 1, 25, 'Sidebar', 0, 1, 0, 0),
(1, 1, 26, 'Sidebar', 1, 1, 0, 0),
(1, 1, 27, 'Main', 0, 1, 0, 0),
(1, 1, 28, 'Header Image', 0, 1, 0, 0),
(118, 1, 29, 'Header', 0, 1, 0, 0),
(118, 1, 30, 'Sidebar', 0, 1, 0, 0),
(118, 1, 31, 'Main', 0, 1, 0, 0),
(118, 1, 18, 'Header Image', 0, 0, 0, 0),
(122, 1, 32, 'Header', 0, 1, 0, 0),
(122, 1, 33, 'Sidebar', 0, 1, 0, 0),
(122, 1, 34, 'Main', 0, 1, 0, 1),
(122, 1, 19, 'Header Image', 0, 0, 0, 0),
(121, 1, 35, 'Header', 0, 1, 0, 0),
(121, 1, 36, 'Sidebar', 0, 1, 0, 0),
(121, 1, 37, 'Main', 0, 1, 0, 0),
(121, 1, 38, 'Main', 1, 1, 0, 0),
(121, 1, 18, 'Header Image', 0, 0, 0, 0),
(120, 1, 39, 'Header', 0, 1, 0, 0),
(120, 1, 40, 'Sidebar', 0, 1, 0, 0),
(120, 1, 41, 'Sidebar', 1, 1, 0, 0),
(120, 1, 42, 'Main', 0, 1, 0, 0),
(120, 1, 19, 'Header Image', 0, 0, 0, 0),
(119, 1, 43, 'Main', 0, 1, 0, 0),
(119, 1, 44, 'Sidebar', 0, 1, 0, 0),
(119, 1, 45, 'Sidebar', 1, 1, 0, 0),
(119, 1, 46, 'Sidebar', 2, 1, 0, 0),
(119, 1, 19, 'Header Image', 0, 0, 0, 0),
(124, 1, 47, 'Header Image', 0, 1, 0, 0),
(124, 1, 14, 'Sidebar', 0, 0, 0, 0),
(124, 1, 48, 'Main', 0, 1, 0, 0),
(124, 1, 49, 'Thumbnail Image', 0, 1, 0, 0),
(123, 1, 19, 'Header Image', 0, 0, 0, 0),
(123, 1, 50, 'Main', 0, 1, 0, 0),
(123, 1, 51, 'Sidebar', 0, 1, 0, 0),
(123, 1, 52, 'Sidebar', 1, 1, 0, 0);


CREATE TABLE IF NOT EXISTS `collectionversionblockstyles` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `cvID` int(10) unsigned NOT NULL DEFAULT '0',
  `bID` int(10) unsigned NOT NULL DEFAULT '0',
  `arHandle` varchar(255) NOT NULL,
  `csrID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cID`,`cvID`,`bID`,`arHandle`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


INSERT INTO `collectionversionblockstyles` (`cID`, `cvID`, `bID`, `arHandle`, `csrID`) VALUES
(118, 1, 18, 'Header Image', 0),
(122, 1, 19, 'Header Image', 0),
(121, 1, 18, 'Header Image', 0),
(120, 1, 19, 'Header Image', 0),
(119, 1, 19, 'Header Image', 0),
(124, 1, 14, 'Sidebar', 0),
(123, 1, 19, 'Header Image', 0);

CREATE TABLE IF NOT EXISTS `collectionversionrelatededits` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `cvID` int(10) unsigned NOT NULL DEFAULT '0',
  `cRelationID` int(10) unsigned NOT NULL DEFAULT '0',
  `cvRelationID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cID`,`cvID`,`cRelationID`,`cvRelationID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `collectionversions` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `cvID` int(10) unsigned NOT NULL DEFAULT '1',
  `cvName` text,
  `cvHandle` varchar(255) DEFAULT NULL,
  `cvDescription` text,
  `cvDatePublic` datetime DEFAULT NULL,
  `cvDateCreated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `cvComments` varchar(255) DEFAULT NULL,
  `cvIsApproved` tinyint(1) NOT NULL DEFAULT '0',
  `cvIsNew` tinyint(1) NOT NULL DEFAULT '0',
  `cvAuthorUID` int(10) unsigned DEFAULT NULL,
  `cvApproverUID` int(10) unsigned DEFAULT NULL,
  `cvActivateDatetime` datetime DEFAULT NULL,
  PRIMARY KEY (`cID`,`cvID`),
  KEY `cvIsApproved` (`cvIsApproved`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `collectionversions` (`cID`, `cvID`, `cvName`, `cvHandle`, `cvDescription`, `cvDatePublic`, `cvDateCreated`, `cvComments`, `cvIsApproved`, `cvIsNew`, `cvAuthorUID`, `cvApproverUID`, `cvActivateDatetime`) VALUES
(1, 1, 'Home', 'home', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(2, 1, 'Dashboard', 'dashboard', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(3, 1, 'Composer', 'composer', 'Write for your site.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(4, 1, 'Write', 'write', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(5, 1, 'Drafts', 'drafts', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(6, 1, 'Sitemap', 'sitemap', 'Whole world at a glance.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(7, 1, 'Full Sitemap', 'full', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(8, 1, 'Flat View', 'explore', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(9, 1, 'Page Search', 'search', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(10, 1, 'Files', 'files', 'All documents and images.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(11, 1, 'File Manager', 'search', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(12, 1, 'Attributes', 'attributes', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(13, 1, 'File Sets', 'sets', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(14, 1, 'Add File Set', 'add_set', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(15, 1, 'Members', 'users', 'Add and manage the user accounts and groups on your website.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(16, 1, 'Search Users', 'search', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(17, 1, 'User Groups', 'groups', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(18, 1, 'Attributes', 'attributes', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(19, 1, 'Add User', 'add', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(20, 1, 'Add Group', 'add_group', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(21, 1, 'Reports', 'reports', 'Get data from forms and logs.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(22, 1, 'Statistics', 'statistics', 'View your site activity.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(23, 1, 'Form Results', 'forms', 'Get submission data.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(24, 1, 'Surveys', 'surveys', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(25, 1, 'Logs', 'logs', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(26, 1, 'Pages & Themes', 'pages', 'Reskin your site.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(27, 1, 'Themes', 'themes', 'Reskin your site.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(28, 1, 'Add', 'add', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(29, 1, 'Inspect', 'inspect', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(30, 1, 'Customize', 'customize', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(31, 1, 'Page Types', 'types', 'What goes in your site.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(32, 1, 'Add Page Type', 'add', 'Add page types to your site.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(33, 1, 'Attributes', 'attributes', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(34, 1, 'Single Pages', 'single', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(35, 1, 'Stacks & Blocks', 'blocks', 'Manage sitewide content and administer block types.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(36, 1, 'Stacks', 'stacks', 'Share content across your site.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(37, 1, 'Stack List', 'list', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(38, 1, 'Block Types', 'types', 'Manage the installed block types in your site.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(39, 1, 'Extend concrete5', 'extend', 'Connect to the concrete5 marketplace, install custom add-ons, and download updates for marketplace add-ons and themes.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(40, 1, 'Dashboard', 'news', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(41, 1, 'Add Functionality', 'install', 'Install add-ons & themes.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(42, 1, 'Update Add-Ons', 'update', 'Update your installed packages.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(43, 1, 'Connect to the Community', 'connect', 'Connect to the concrete5 community.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(44, 1, 'Get More Themes', 'themes', 'Download themes from concrete5.org.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(45, 1, 'Get More Add-Ons', 'add-ons', 'Download add-ons from concrete5.org.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(46, 1, 'System & Settings', 'system', 'Secure and setup your site.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(47, 1, 'Basics', 'basics', 'Basic information about your website.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(48, 1, 'Site Name', 'site_name', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(49, 1, 'Bookmark Icons', 'icons', 'Bookmark icon and mobile home screen icon setup.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(50, 1, 'Rich Text Editor', 'editor', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(51, 1, 'Languages', 'multilingual', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(52, 1, 'Time Zone', 'timezone', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(53, 1, 'Interface Preferences', 'interface', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(54, 1, 'SEO & Statistics', 'seo', 'Enable pretty URLs, statistics and tracking codes.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(55, 1, 'Pretty URLs', 'urls', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(56, 1, 'Tracking Codes', 'tracking_codes', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(57, 1, 'Statistics', 'statistics', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(58, 1, 'Search Index', 'search_index', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(59, 1, 'Optimization', 'optimization', 'Keep your site running well.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(60, 1, 'Cache & Speed Settings', 'cache', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(61, 1, 'Clear Cache', 'clear_cache', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(62, 1, 'Automated Jobs', 'jobs', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(63, 1, 'Permissions & Access', 'permissions', 'Control who sees and edits your site.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(64, 1, 'Site Access', 'site', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(65, 1, 'File Manager Permissions', 'files', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(66, 1, 'Allowed File Types', 'file_types', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(67, 1, 'Task Permissions', 'tasks', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(68, 1, 'IP Blacklist', 'ip_blacklist', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(69, 1, 'Captcha Setup', 'captcha', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(70, 1, 'Spam Control', 'antispam', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(71, 1, 'Maintenance Mode', 'maintenance_mode', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(72, 1, 'Login & Registration', 'registration', 'Change login behaviors and setup public profiles.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(73, 1, 'Login Destination', 'postlogin', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(74, 1, 'Public Profiles', 'profiles', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(75, 1, 'Public Registration', 'public_registration', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(76, 1, 'Email', 'mail', 'Control how your site send and processes mail.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(77, 1, 'SMTP Method', 'method', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(78, 1, 'Email Importers', 'importers', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(79, 1, 'Attributes', 'attributes', 'Setup attributes for pages, users, files and more.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(80, 1, 'Sets', 'sets', 'Group attributes into sets for easier organization', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(81, 1, 'Types', 'types', 'Choose which attribute types are available for different items.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(82, 1, 'Environment', 'environment', 'Advanced settings for web developers.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(83, 1, 'Environment Information', 'info', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(84, 1, 'Debug Settings', 'debug', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(85, 1, 'Logging Settings', 'logging', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(86, 1, 'File Storage Locations', 'file_storage_locations', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(87, 1, 'Backup & Restore', 'backup_restore', 'Backup or restore your website.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(88, 1, 'Backup Database', 'backup', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(89, 1, 'Update concrete5', 'update', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(90, 1, 'Database XML', 'database', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(91, 1, 'Composer', 'composer', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(92, 1, '', NULL, NULL, NOW(), NOW(), 'Initial Version', 1, 1, NULL, NULL, NULL),
(93, 1, '', NULL, NULL, NOW(), NOW(), 'Initial Version', 1, 1, NULL, NULL, NULL),
(94, 1, '', NULL, NULL, NOW(), NOW(), 'Initial Version', 1, 1, NULL, NULL, NULL),
(95, 1, 'Customize Dashboard Home', 'home', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(96, 1, 'Welcome to concrete5', 'welcome', 'Learn about how to use concrete5, how to develop for concrete5, and get general help.', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(97, 1, 'Drafts', '!drafts', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(98, 1, 'Trash', '!trash', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(99, 1, 'Stacks', '!stacks', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(100, 1, 'Login', 'login', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(101, 1, 'Register', 'register', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(102, 1, 'Profile', 'profile', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(103, 1, 'Edit', 'edit', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(104, 1, 'Avatar', 'avatar', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(105, 1, 'Messages', 'messages', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(106, 1, 'Friends', 'friends', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(107, 1, 'Page Not Found', 'page_not_found', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(108, 1, 'Page Forbidden', 'page_forbidden', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(109, 1, 'Download File', 'download_file', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(110, 1, 'Members', 'members', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(111, 1, 'Header Nav', 'header-nav', NULL, NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(112, 1, 'Side Nav', 'side-nav', NULL, NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(113, 1, 'Site Name', 'site-name', NULL, NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(114, 1, '', NULL, NULL, NOW(), NOW(), 'Initial Version', 1, 1, NULL, NULL, NULL),
(115, 1, '', NULL, NULL, NOW(), NOW(), 'Initial Version', 1, 1, NULL, NULL, NULL),
(116, 1, '', NULL, NULL, NOW(), NOW(), 'Initial Version', 1, 1, NULL, NULL, NULL),
(117, 1, '', NULL, NULL, NOW(), NOW(), 'Initial Version', 1, 1, NULL, NULL, NULL),
(118, 1, 'About', 'about', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(119, 1, 'Blog', 'blog', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(120, 1, 'Search', 'search', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(121, 1, 'Contact Us', 'contact-us', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(122, 1, 'Guestbook', 'guestbook', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(123, 1, 'Blog Archives', 'blog-archives', '', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL),
(124, 1, 'Hello World', 'hello-world', 'This is my first blog post!', NOW(), NOW(), 'Initial Version', 1, 1, 1, NULL, NULL);

CREATE TABLE IF NOT EXISTS `composercontentlayout` (
  `cclID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bID` int(10) unsigned NOT NULL DEFAULT '0',
  `akID` int(10) unsigned NOT NULL DEFAULT '0',
  `displayOrder` int(10) unsigned NOT NULL DEFAULT '0',
  `ctID` int(10) unsigned NOT NULL DEFAULT '0',
  `ccFilename` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`cclID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

INSERT INTO `composercontentlayout` (`cclID`, `bID`, `akID`, `displayOrder`, `ctID`, `ccFilename`) VALUES
(1, 16, 0, 1, 4, 'header.php'),
(2, 15, 0, 2, 4, 'thumbnail.php'),
(3, 13, 0, 3, 4, ''),
(4, 0, 13, 4, 4, NULL);


CREATE TABLE IF NOT EXISTS `composerdrafts` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `cpPublishParentID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `composertypes` (
  `ctID` int(10) unsigned NOT NULL DEFAULT '0',
  `ctComposerPublishPageMethod` varchar(64) NOT NULL DEFAULT 'CHOOSE',
  `ctComposerPublishPageTypeID` int(10) unsigned NOT NULL DEFAULT '0',
  `ctComposerPublishPageParentID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ctID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


INSERT INTO `composertypes` (`ctID`, `ctComposerPublishPageMethod`, `ctComposerPublishPageTypeID`, `ctComposerPublishPageParentID`) VALUES
(4, 'PARENT', 0, 119);


CREATE TABLE IF NOT EXISTS `config` (
  `cfKey` varchar(64) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `cfValue` longtext,
  `uID` int(10) unsigned NOT NULL DEFAULT '0',
  `pkgID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cfKey`,`uID`),
  KEY `uID` (`uID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


INSERT INTO `config` (`cfKey`, `timestamp`, `cfValue`, `uID`, `pkgID`) VALUES
('SITE_DEBUG_LEVEL', NOW(), '1', 0, 0),
('ENABLE_LOG_EMAILS', NOW(), '1', 0, 0),
('ENABLE_LOG_ERRORS', NOW(), '1', 0, 0),
('ENABLE_CACHE', NOW(), '1', 0, 0),
('FULL_PAGE_CACHE_GLOBAL', NOW(), '0', 0, 0),
('ENABLE_MARKETPLACE_SUPPORT', NOW(), '1', 0, 0),
('ANTISPAM_LOG_SPAM', NOW(), '1', 0, 0),
('SITE', NOW(), 'Concrete5', 0, 0),
('SITE_APP_VERSION', NOW(), '5.5.2.1', 0, 0),
('NEWSFLOW_LAST_VIEWED', '2012-07-12 14:46:49', '1342084609', 1, 0),
('APP_VERSION_LATEST', '2012-07-12 09:16:34', '5.5.2.1', 0, 0),
('SEEN_INTRODUCTION', '2012-07-12 09:16:46', '1', 0, 0);


CREATE TABLE IF NOT EXISTS `customstylepresets` (
  `cspID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cspName` varchar(255) NOT NULL,
  `csrID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cspID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `customstylerules` (
  `csrID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `css_id` varchar(128) DEFAULT NULL,
  `css_class` varchar(128) DEFAULT NULL,
  `css_serialized` text,
  `css_custom` text,
  PRIMARY KEY (`csrID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;


CREATE TABLE IF NOT EXISTS `dashboardhomepage` (
  `dbhID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dbhModule` varchar(255) NOT NULL,
  `dbhDisplayName` varchar(255) DEFAULT NULL,
  `dbhDisplayOrder` int(10) unsigned NOT NULL DEFAULT '0',
  `pkgID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`dbhID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;


CREATE TABLE IF NOT EXISTS `downloadstatistics` (
  `dsID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fID` int(10) unsigned NOT NULL,
  `fvID` int(10) unsigned NOT NULL,
  `uID` int(10) unsigned NOT NULL,
  `rcID` int(10) unsigned NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`dsID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;


CREATE TABLE IF NOT EXISTS `fileattributevalues` (
  `fID` int(10) unsigned NOT NULL DEFAULT '0',
  `fvID` int(10) unsigned NOT NULL DEFAULT '0',
  `akID` int(10) unsigned NOT NULL DEFAULT '0',
  `avID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`fID`,`fvID`,`akID`,`avID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `fileattributevalues`
--

INSERT INTO `fileattributevalues` (`fID`, `fvID`, `akID`, `avID`) VALUES
(1, 1, 11, 76),
(1, 1, 12, 77),
(2, 1, 11, 78),
(2, 1, 12, 79),
(3, 1, 11, 80),
(3, 1, 12, 81),
(4, 1, 11, 82),
(4, 1, 12, 83),
(5, 1, 11, 84),
(5, 1, 12, 85),
(6, 1, 11, 86),
(6, 1, 12, 87),
(7, 1, 11, 88),
(7, 1, 12, 89),
(8, 1, 11, 90),
(8, 1, 12, 91);

-- --------------------------------------------------------

--
-- Table structure for table `filepermissionfiletypes`
--

CREATE TABLE IF NOT EXISTS `filepermissionfiletypes` (
  `fsID` int(10) unsigned NOT NULL DEFAULT '0',
  `gID` int(10) unsigned NOT NULL DEFAULT '0',
  `uID` int(10) unsigned NOT NULL DEFAULT '0',
  `extension` varchar(32) NOT NULL,
  PRIMARY KEY (`fsID`,`gID`,`uID`,`extension`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `filepermissionfiletypes`
--


-- --------------------------------------------------------

--
-- Table structure for table `filepermissions`
--

CREATE TABLE IF NOT EXISTS `filepermissions` (
  `fID` int(10) unsigned NOT NULL DEFAULT '0',
  `gID` int(10) unsigned NOT NULL DEFAULT '0',
  `uID` int(10) unsigned NOT NULL DEFAULT '0',
  `canRead` int(4) NOT NULL DEFAULT '0',
  `canWrite` int(4) NOT NULL DEFAULT '0',
  `canAdmin` int(4) NOT NULL DEFAULT '0',
  `canSearch` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`fID`,`gID`,`uID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `filepermissions`
--


-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE IF NOT EXISTS `files` (
  `fID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fDateAdded` datetime DEFAULT NULL,
  `uID` int(10) unsigned NOT NULL DEFAULT '0',
  `fslID` int(10) unsigned NOT NULL DEFAULT '0',
  `ocID` int(10) unsigned NOT NULL DEFAULT '0',
  `fOverrideSetPermissions` int(1) NOT NULL DEFAULT '0',
  `fPassword` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`fID`,`uID`,`fslID`),
  KEY `fOverrideSetPermissions` (`fOverrideSetPermissions`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`fID`, `fDateAdded`, `uID`, `fslID`, `ocID`, `fOverrideSetPermissions`, `fPassword`) VALUES
(1, NOW(), 1, 0, 0, 0, NULL),
(2, NOW(), 1, 0, 0, 0, NULL),
(3, NOW(), 1, 0, 0, 0, NULL),
(4, NOW(), 1, 0, 0, 0, NULL),
(5, NOW(), 1, 0, 0, 0, NULL),
(6, NOW(), 1, 0, 0, 0, NULL),
(7, NOW(), 1, 0, 0, 0, NULL),
(8, NOW(), 1, 0, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `filesearchindexattributes`
--

CREATE TABLE IF NOT EXISTS `filesearchindexattributes` (
  `fID` int(11) unsigned NOT NULL DEFAULT '0',
  `ak_width` decimal(14,4) DEFAULT '0.0000',
  `ak_height` decimal(14,4) DEFAULT '0.0000',
  PRIMARY KEY (`fID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `filesearchindexattributes`
--

INSERT INTO `filesearchindexattributes` (`fID`, `ak_width`, `ak_height`) VALUES
(1, 960.0000, 212.0000),
(2, 960.0000, 212.0000),
(3, 960.0000, 212.0000),
(4, 960.0000, 212.0000),
(5, 960.0000, 212.0000),
(6, 960.0000, 212.0000),
(7, 960.0000, 212.0000),
(8, 150.0000, 150.0000);

-- --------------------------------------------------------

--
-- Table structure for table `filesetfiles`
--

CREATE TABLE IF NOT EXISTS `filesetfiles` (
  `fsfID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fID` int(10) unsigned NOT NULL,
  `fsID` int(10) unsigned NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `fsDisplayOrder` int(10) unsigned NOT NULL,
  PRIMARY KEY (`fsfID`),
  KEY `fID` (`fID`),
  KEY `fsID` (`fsID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `filesetfiles`
--


-- --------------------------------------------------------

--
-- Table structure for table `filesetpermissions`
--

CREATE TABLE IF NOT EXISTS `filesetpermissions` (
  `fsID` int(10) unsigned NOT NULL DEFAULT '0',
  `gID` int(10) unsigned NOT NULL DEFAULT '0',
  `uID` int(10) unsigned NOT NULL DEFAULT '0',
  `canRead` int(4) DEFAULT NULL,
  `canWrite` int(4) DEFAULT NULL,
  `canAdmin` int(4) DEFAULT NULL,
  `canAdd` int(4) DEFAULT NULL,
  `canSearch` int(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`fsID`,`gID`,`uID`),
  KEY `canRead` (`canRead`),
  KEY `canWrite` (`canWrite`),
  KEY `canAdmin` (`canAdmin`),
  KEY `canSearch` (`canSearch`),
  KEY `canAdd` (`canAdd`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `filesetpermissions`
--

INSERT INTO `filesetpermissions` (`fsID`, `gID`, `uID`, `canRead`, `canWrite`, `canAdmin`, `canAdd`, `canSearch`) VALUES
(0, 1, 0, 10, 0, 0, 0, 0),
(0, 2, 0, 10, 0, 0, 0, 0),
(0, 3, 0, 10, 10, 10, 10, 10);

-- --------------------------------------------------------

--
-- Table structure for table `filesets`
--

CREATE TABLE IF NOT EXISTS `filesets` (
  `fsID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fsName` varchar(64) NOT NULL,
  `uID` int(10) unsigned NOT NULL DEFAULT '0',
  `fsType` int(4) NOT NULL,
  `fsOverrideGlobalPermissions` int(4) DEFAULT NULL,
  PRIMARY KEY (`fsID`),
  KEY `fsOverrideGlobalPermissions` (`fsOverrideGlobalPermissions`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `filesets`
--


-- --------------------------------------------------------

--
-- Table structure for table `filesetsavedsearches`
--

CREATE TABLE IF NOT EXISTS `filesetsavedsearches` (
  `fsID` int(10) unsigned NOT NULL DEFAULT '0',
  `fsSearchRequest` text,
  `fsResultColumns` text,
  PRIMARY KEY (`fsID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `filesetsavedsearches`
--


-- --------------------------------------------------------

--
-- Table structure for table `filestoragelocations`
--

CREATE TABLE IF NOT EXISTS `filestoragelocations` (
  `fslID` int(10) unsigned NOT NULL DEFAULT '0',
  `fslName` varchar(255) NOT NULL,
  `fslDirectory` varchar(255) NOT NULL,
  PRIMARY KEY (`fslID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `filestoragelocations`
--


-- --------------------------------------------------------

--
-- Table structure for table `fileversionlog`
--

CREATE TABLE IF NOT EXISTS `fileversionlog` (
  `fvlID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fID` int(10) unsigned NOT NULL DEFAULT '0',
  `fvID` int(10) unsigned NOT NULL DEFAULT '0',
  `fvUpdateTypeID` int(3) unsigned NOT NULL DEFAULT '0',
  `fvUpdateTypeAttributeID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`fvlID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `fileversionlog`
--

INSERT INTO `fileversionlog` (`fvlID`, `fID`, `fvID`, `fvUpdateTypeID`, `fvUpdateTypeAttributeID`) VALUES
(1, 1, 1, 5, 11),
(2, 1, 1, 5, 12),
(3, 2, 1, 5, 11),
(4, 2, 1, 5, 12),
(5, 3, 1, 5, 11),
(6, 3, 1, 5, 12),
(7, 4, 1, 5, 11),
(8, 4, 1, 5, 12),
(9, 5, 1, 5, 11),
(10, 5, 1, 5, 12),
(11, 6, 1, 5, 11),
(12, 6, 1, 5, 12),
(13, 7, 1, 5, 11),
(14, 7, 1, 5, 12),
(15, 8, 1, 5, 11),
(16, 8, 1, 5, 12);

-- --------------------------------------------------------

--
-- Table structure for table `fileversions`
--

CREATE TABLE IF NOT EXISTS `fileversions` (
  `fID` int(10) unsigned NOT NULL DEFAULT '0',
  `fvID` int(10) unsigned NOT NULL DEFAULT '0',
  `fvFilename` varchar(255) NOT NULL,
  `fvPrefix` varchar(12) DEFAULT NULL,
  `fvGenericType` int(3) unsigned NOT NULL DEFAULT '0',
  `fvSize` int(20) unsigned NOT NULL DEFAULT '0',
  `fvTitle` varchar(255) DEFAULT NULL,
  `fvDescription` text,
  `fvTags` varchar(255) DEFAULT NULL,
  `fvIsApproved` int(10) unsigned NOT NULL DEFAULT '1',
  `fvDateAdded` datetime DEFAULT NULL,
  `fvApproverUID` int(10) unsigned NOT NULL DEFAULT '0',
  `fvAuthorUID` int(10) unsigned NOT NULL DEFAULT '0',
  `fvActivateDatetime` datetime DEFAULT NULL,
  `fvHasThumbnail1` int(1) NOT NULL DEFAULT '0',
  `fvHasThumbnail2` int(1) NOT NULL DEFAULT '0',
  `fvHasThumbnail3` int(1) NOT NULL DEFAULT '0',
  `fvExtension` varchar(32) DEFAULT NULL,
  `fvType` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`fID`,`fvID`),
  KEY `fvExtension` (`fvType`),
  KEY `fvTitle` (`fvTitle`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `fileversions`
--

INSERT INTO `fileversions` (`fID`, `fvID`, `fvFilename`, `fvPrefix`, `fvGenericType`, `fvSize`, `fvTitle`, `fvDescription`, `fvTags`, `fvIsApproved`, `fvDateAdded`, `fvApproverUID`, `fvAuthorUID`, `fvActivateDatetime`, `fvHasThumbnail1`, `fvHasThumbnail2`, `fvHasThumbnail3`, `fvExtension`, `fvType`) VALUES
(1, 1, 'england_village.jpg', '991342084586', 1, 333117, 'england_village.jpg', '', '', 1, NOW(), 1, 1, NOW(), 1, 1, 0, 'jpg', 1),
(2, 1, 'europe_england_stonehenge.jpg', '501342084587', 1, 286856, 'europe_england_stonehenge.jpg', '', '', 1, NOW(), 1, 1, NOW(), 1, 1, 0, 'jpg', 1),
(3, 1, 'europe_germany_munich_arch.jpg', '741342084587', 1, 229235, 'europe_germany_munich_arch.jpg', '', '', 1, NOW(), 1, 1, NOW(), 1, 1, 0, 'jpg', 1),
(4, 1, 'europe_rotterdam_port.jpg', '301342084587', 1, 203784, 'europe_rotterdam_port.jpg', '', '', 1, NOW(), 1, 1, NOW(), 1, 1, 0, 'jpg', 1),
(5, 1, 'europe_spain_grenada_alhambra.jpg', '901342084588', 1, 320805, 'europe_spain_grenada_alhambra.jpg', '', '', 1, NOW(), 1, 1, NOW(), 1, 1, 0, 'jpg', 1),
(6, 1, 'europe_valencia_hemispheric.jpg', '431342084588', 1, 262679, 'europe_valencia_hemispheric.jpg', '', '', 1, NOW(), 1, 1, NOW(), 1, 1, 0, 'jpg', 1),
(7, 1, 'northern_az_lake_powell_house_boats.jpg', '231342084588', 1, 226976, 'northern_az_lake_powell_house_boats.jpg', '', '', 1, NOW(), 1, 1, NOW(), 1, 1, 0, 'jpg', 1),
(8, 1, 'sh_thumbnail.jpg', '631342084589', 1, 15243, 'sh_thumbnail.jpg', '', '', 1, NOW(), 1, 1, NOW(), 1, 1, 0, 'jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `gID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gName` varchar(128) NOT NULL,
  `gDescription` varchar(255) NOT NULL,
  `gUserExpirationIsEnabled` int(1) NOT NULL DEFAULT '0',
  `gUserExpirationMethod` varchar(12) DEFAULT NULL,
  `gUserExpirationSetDateTime` datetime DEFAULT NULL,
  `gUserExpirationInterval` int(10) unsigned NOT NULL DEFAULT '0',
  `gUserExpirationAction` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`gID`),
  UNIQUE KEY `gName` (`gName`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`gID`, `gName`, `gDescription`, `gUserExpirationIsEnabled`, `gUserExpirationMethod`, `gUserExpirationSetDateTime`, `gUserExpirationInterval`, `gUserExpirationAction`) VALUES
(1, 'Guest', 'The guest group represents unregistered visitors to your site.', 0, NULL, NULL, 0, NULL),
(2, 'Registered Users', 'The registered users group represents all user accounts.', 0, NULL, NULL, 0, NULL),
(3, 'Administrators', '', 0, NULL, NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE IF NOT EXISTS `jobs` (
  `jID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `jName` varchar(100) NOT NULL,
  `jDescription` varchar(255) NOT NULL,
  `jDateInstalled` datetime DEFAULT NULL,
  `jDateLastRun` datetime DEFAULT NULL,
  `pkgID` int(10) unsigned NOT NULL DEFAULT '0',
  `jLastStatusText` varchar(255) DEFAULT NULL,
  `jLastStatusCode` smallint(4) NOT NULL DEFAULT '0',
  `jStatus` varchar(14) NOT NULL DEFAULT 'ENABLED',
  `jHandle` varchar(255) NOT NULL,
  `jNotUninstallable` smallint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`jID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`jID`, `jName`, `jDescription`, `jDateInstalled`, `jDateLastRun`, `pkgID`, `jLastStatusText`, `jLastStatusCode`, `jStatus`, `jHandle`, `jNotUninstallable`) VALUES
(1, 'Index Search Engine', 'Index the site to allow searching to work quickly and accurately.', NOW(), NULL, 0, NULL, 0, 'ENABLED', 'index_search', 1),
(2, 'Generate Sitemap File', 'Generate the sitemap.xml file that search engines use to crawl your site.', NOW(), NULL, 0, NULL, 0, 'ENABLED', 'generate_sitemap', 0),
(3, 'Process Email Posts', 'Polls an email account and grabs private messages/postings that are sent there..', NOW(), NULL, 0, NULL, 0, 'ENABLED', 'process_email', 0),
(4, 'Remove Old Page Versions', 'Removes all except the 10 most recent page versions for each page.', NOW(), NULL, 0, NULL, 0, 'ENABLED', 'remove_old_page_versions', 0);

-- --------------------------------------------------------

--
-- Table structure for table `jobslog`
--

CREATE TABLE IF NOT EXISTS `jobslog` (
  `jlID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `jID` int(10) unsigned NOT NULL,
  `jlMessage` varchar(255) NOT NULL,
  `jlTimestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `jlError` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`jlID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jobslog`
--


-- --------------------------------------------------------

--
-- Table structure for table `layoutpresets`
--

CREATE TABLE IF NOT EXISTS `layoutpresets` (
  `lpID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lpName` varchar(128) NOT NULL,
  `layoutID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`lpID`),
  UNIQUE KEY `layoutID` (`layoutID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `layoutpresets`
--


-- --------------------------------------------------------

--
-- Table structure for table `layouts`
--

CREATE TABLE IF NOT EXISTS `layouts` (
  `layoutID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `layout_rows` int(5) NOT NULL DEFAULT '3',
  `layout_columns` int(3) NOT NULL DEFAULT '3',
  `spacing` int(3) NOT NULL DEFAULT '3',
  `breakpoints` varchar(255) NOT NULL DEFAULT '',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`layoutID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `layouts`
--


-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE IF NOT EXISTS `logs` (
  `logID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `logType` varchar(64) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `logText` longtext,
  `logIsInternal` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`logID`),
  KEY `logType` (`logType`),
  KEY `logIsInternal` (`logIsInternal`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `logs`
--


-- --------------------------------------------------------

--
-- Table structure for table `mailimporters`
--

CREATE TABLE IF NOT EXISTS `mailimporters` (
  `miID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `miHandle` varchar(64) NOT NULL,
  `miServer` varchar(255) DEFAULT NULL,
  `miUsername` varchar(255) DEFAULT NULL,
  `miPassword` varchar(255) DEFAULT NULL,
  `miEncryption` varchar(32) DEFAULT NULL,
  `miIsEnabled` int(1) NOT NULL DEFAULT '0',
  `miEmail` varchar(255) DEFAULT NULL,
  `miPort` int(10) unsigned NOT NULL DEFAULT '0',
  `pkgID` int(10) unsigned DEFAULT NULL,
  `miConnectionMethod` varchar(8) DEFAULT 'POP',
  PRIMARY KEY (`miID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `mailimporters`
--

INSERT INTO `mailimporters` (`miID`, `miHandle`, `miServer`, `miUsername`, `miPassword`, `miEncryption`, `miIsEnabled`, `miEmail`, `miPort`, `pkgID`, `miConnectionMethod`) VALUES
(1, 'private_message', NULL, NULL, NULL, NULL, 0, NULL, 0, 0, 'POP');

-- --------------------------------------------------------

--
-- Table structure for table `mailvalidationhashes`
--

CREATE TABLE IF NOT EXISTS `mailvalidationhashes` (
  `mvhID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `miID` int(10) unsigned NOT NULL DEFAULT '0',
  `email` varchar(255) NOT NULL,
  `mHash` varchar(128) NOT NULL,
  `mDateGenerated` int(10) unsigned NOT NULL DEFAULT '0',
  `mDateRedeemed` int(10) unsigned NOT NULL DEFAULT '0',
  `data` text,
  PRIMARY KEY (`mvhID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mailvalidationhashes`
--


-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE IF NOT EXISTS `packages` (
  `pkgID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pkgName` varchar(255) NOT NULL,
  `pkgHandle` varchar(64) NOT NULL,
  `pkgDescription` text,
  `pkgDateInstalled` datetime NOT NULL,
  `pkgIsInstalled` tinyint(1) NOT NULL DEFAULT '1',
  `pkgVersion` varchar(32) DEFAULT NULL,
  `pkgAvailableVersion` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`pkgID`),
  UNIQUE KEY `pkgHandle` (`pkgHandle`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `packages`
--


-- --------------------------------------------------------

--
-- Table structure for table `pagepaths`
--

CREATE TABLE IF NOT EXISTS `pagepaths` (
  `ppID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cID` int(10) unsigned DEFAULT '0',
  `cPath` text,
  `ppIsCanonical` varchar(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ppID`),
  KEY `cID` (`cID`),
  KEY `ppIsCanonical` (`ppIsCanonical`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=117 ;

--
-- Dumping data for table `pagepaths`
--

INSERT INTO `pagepaths` (`ppID`, `cID`, `cPath`, `ppIsCanonical`) VALUES
(1, 2, '/dashboard', '1'),
(2, 3, '/dashboard/composer', '1'),
(3, 4, '/dashboard/composer/write', '1'),
(4, 5, '/dashboard/composer/drafts', '1'),
(5, 6, '/dashboard/sitemap', '1'),
(6, 7, '/dashboard/sitemap/full', '1'),
(7, 8, '/dashboard/sitemap/explore', '1'),
(8, 9, '/dashboard/sitemap/search', '1'),
(9, 10, '/dashboard/files', '1'),
(10, 11, '/dashboard/files/search', '1'),
(11, 12, '/dashboard/files/attributes', '1'),
(12, 13, '/dashboard/files/sets', '1'),
(13, 14, '/dashboard/files/add_set', '1'),
(14, 15, '/dashboard/users', '1'),
(15, 16, '/dashboard/users/search', '1'),
(16, 17, '/dashboard/users/groups', '1'),
(17, 18, '/dashboard/users/attributes', '1'),
(18, 19, '/dashboard/users/add', '1'),
(19, 20, '/dashboard/users/add_group', '1'),
(20, 21, '/dashboard/reports', '1'),
(21, 22, '/dashboard/reports/statistics', '1'),
(22, 23, '/dashboard/reports/forms', '1'),
(23, 24, '/dashboard/reports/surveys', '1'),
(24, 25, '/dashboard/reports/logs', '1'),
(25, 26, '/dashboard/pages', '1'),
(26, 27, '/dashboard/pages/themes', '1'),
(27, 28, '/dashboard/pages/themes/add', '1'),
(28, 29, '/dashboard/pages/themes/inspect', '1'),
(29, 30, '/dashboard/pages/themes/customize', '1'),
(30, 31, '/dashboard/pages/types', '1'),
(31, 32, '/dashboard/pages/types/add', '1'),
(32, 33, '/dashboard/pages/attributes', '1'),
(33, 34, '/dashboard/pages/single', '1'),
(34, 35, '/dashboard/blocks', '1'),
(35, 36, '/dashboard/blocks/stacks', '1'),
(36, 37, '/dashboard/blocks/stacks/list', '1'),
(37, 38, '/dashboard/blocks/types', '1'),
(38, 39, '/dashboard/extend', '1'),
(39, 40, '/dashboard/news', '1'),
(40, 41, '/dashboard/extend/install', '1'),
(41, 42, '/dashboard/extend/update', '1'),
(42, 43, '/dashboard/extend/connect', '1'),
(43, 44, '/dashboard/extend/themes', '1'),
(44, 45, '/dashboard/extend/add-ons', '1'),
(45, 46, '/dashboard/system', '1'),
(46, 47, '/dashboard/system/basics', '1'),
(47, 48, '/dashboard/system/basics/site_name', '1'),
(48, 49, '/dashboard/system/basics/icons', '1'),
(49, 50, '/dashboard/system/basics/editor', '1'),
(50, 51, '/dashboard/system/basics/multilingual', '1'),
(51, 52, '/dashboard/system/basics/timezone', '1'),
(52, 53, '/dashboard/system/basics/interface', '1'),
(53, 54, '/dashboard/system/seo', '1'),
(54, 55, '/dashboard/system/seo/urls', '1'),
(55, 56, '/dashboard/system/seo/tracking_codes', '1'),
(56, 57, '/dashboard/system/seo/statistics', '1'),
(57, 58, '/dashboard/system/seo/search_index', '1'),
(58, 59, '/dashboard/system/optimization', '1'),
(59, 60, '/dashboard/system/optimization/cache', '1'),
(60, 61, '/dashboard/system/optimization/clear_cache', '1'),
(61, 62, '/dashboard/system/optimization/jobs', '1'),
(62, 63, '/dashboard/system/permissions', '1'),
(63, 64, '/dashboard/system/permissions/site', '1'),
(64, 65, '/dashboard/system/permissions/files', '1'),
(65, 66, '/dashboard/system/permissions/file_types', '1'),
(66, 67, '/dashboard/system/permissions/tasks', '1'),
(67, 68, '/dashboard/system/permissions/ip_blacklist', '1'),
(68, 69, '/dashboard/system/permissions/captcha', '1'),
(69, 70, '/dashboard/system/permissions/antispam', '1'),
(70, 71, '/dashboard/system/permissions/maintenance_mode', '1'),
(71, 72, '/dashboard/system/registration', '1'),
(72, 73, '/dashboard/system/registration/postlogin', '1'),
(73, 74, '/dashboard/system/registration/profiles', '1'),
(74, 75, '/dashboard/system/registration/public_registration', '1'),
(75, 76, '/dashboard/system/mail', '1'),
(76, 77, '/dashboard/system/mail/method', '1'),
(77, 78, '/dashboard/system/mail/importers', '1'),
(78, 79, '/dashboard/system/attributes', '1'),
(79, 80, '/dashboard/system/attributes/sets', '1'),
(80, 81, '/dashboard/system/attributes/types', '1'),
(81, 82, '/dashboard/system/environment', '1'),
(82, 83, '/dashboard/system/environment/info', '1'),
(83, 84, '/dashboard/system/environment/debug', '1'),
(84, 85, '/dashboard/system/environment/logging', '1'),
(85, 86, '/dashboard/system/environment/file_storage_locations', '1'),
(86, 87, '/dashboard/system/backup_restore', '1'),
(87, 88, '/dashboard/system/backup_restore/backup', '1'),
(88, 89, '/dashboard/system/backup_restore/update', '1'),
(89, 90, '/dashboard/system/backup_restore/database', '1'),
(90, 91, '/dashboard/pages/types/composer', '1'),
(91, 95, '/dashboard/home', '1'),
(92, 96, '/dashboard/welcome', '1'),
(93, 97, '/!drafts', '1'),
(94, 98, '/!trash', '1'),
(95, 99, '/!stacks', '1'),
(96, 100, '/login', '1'),
(97, 101, '/register', '1'),
(98, 102, '/profile', '1'),
(99, 103, '/profile/edit', '1'),
(100, 104, '/profile/avatar', '1'),
(101, 105, '/profile/messages', '1'),
(102, 106, '/profile/friends', '1'),
(103, 107, '/page_not_found', '1'),
(104, 108, '/page_forbidden', '1'),
(105, 109, '/download_file', '1'),
(106, 110, '/members', '1'),
(107, 111, '/!stacks/header-nav', '1'),
(108, 112, '/!stacks/side-nav', '1'),
(109, 113, '/!stacks/site-name', '1'),
(110, 118, '/about', '1'),
(111, 119, '/blog', '1'),
(112, 120, '/search', '1'),
(113, 121, '/about/contact-us', '1'),
(114, 122, '/about/guestbook', '1'),
(115, 123, '/blog/blog-archives', '1'),
(116, 124, '/blog/hello-world', '1');

-- --------------------------------------------------------

--
-- Table structure for table `pagepermissionpagetypes`
--

CREATE TABLE IF NOT EXISTS `pagepermissionpagetypes` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `gID` int(10) unsigned NOT NULL DEFAULT '0',
  `uID` int(10) unsigned NOT NULL DEFAULT '0',
  `ctID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cID`,`gID`,`uID`,`ctID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pagepermissionpagetypes`
--


-- --------------------------------------------------------

--
-- Table structure for table `pagepermissions`
--

CREATE TABLE IF NOT EXISTS `pagepermissions` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `gID` int(10) unsigned NOT NULL DEFAULT '0',
  `uID` int(10) unsigned NOT NULL DEFAULT '0',
  `cgPermissions` varchar(32) DEFAULT NULL,
  `cgStartDate` datetime DEFAULT NULL,
  `cgEndDate` datetime DEFAULT NULL,
  PRIMARY KEY (`cID`,`gID`,`uID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pagepermissions`
--

INSERT INTO `pagepermissions` (`cID`, `gID`, `uID`, `cgPermissions`, `cgStartDate`, `cgEndDate`) VALUES
(2, 3, 0, 'r:wa:adm', NULL, NULL),
(37, 3, 0, 'r:wa:adm', NULL, NULL),
(37, 1, 0, 'r', NULL, NULL),
(100, 1, 0, 'r', NULL, NULL),
(100, 2, 0, 'r', NULL, NULL),
(101, 1, 0, 'r', NULL, NULL),
(1, 1, 0, 'r', NULL, NULL),
(1, 3, 0, 'r:rv:wa:db:av:dc:adm', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `ctID` int(10) unsigned NOT NULL DEFAULT '0',
  `cIsTemplate` int(1) unsigned NOT NULL DEFAULT '0',
  `uID` int(10) unsigned DEFAULT NULL,
  `cIsCheckedOut` tinyint(1) NOT NULL DEFAULT '0',
  `cCheckedOutUID` int(10) unsigned DEFAULT NULL,
  `cCheckedOutDatetime` datetime DEFAULT NULL,
  `cCheckedOutDatetimeLastEdit` datetime DEFAULT NULL,
  `cPendingAction` varchar(6) DEFAULT NULL,
  `cPendingActionDatetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `cPendingActionUID` int(10) unsigned DEFAULT NULL,
  `cPendingActionTargetCID` int(10) unsigned DEFAULT NULL,
  `cOverrideTemplatePermissions` tinyint(1) NOT NULL DEFAULT '1',
  `cInheritPermissionsFromCID` int(10) unsigned NOT NULL DEFAULT '0',
  `cInheritPermissionsFrom` varchar(8) NOT NULL DEFAULT 'PARENT',
  `cFilename` varchar(255) DEFAULT NULL,
  `cPointerID` int(10) unsigned NOT NULL DEFAULT '0',
  `cPointerExternalLink` varchar(255) DEFAULT NULL,
  `cPointerExternalLinkNewWindow` tinyint(1) NOT NULL DEFAULT '0',
  `cIsActive` tinyint(1) NOT NULL DEFAULT '1',
  `cChildren` int(10) unsigned NOT NULL DEFAULT '0',
  `cDisplayOrder` int(10) unsigned NOT NULL DEFAULT '0',
  `cParentID` int(10) unsigned NOT NULL DEFAULT '0',
  `pkgID` int(10) unsigned NOT NULL DEFAULT '0',
  `ptID` int(10) unsigned NOT NULL DEFAULT '0',
  `cCacheFullPageContent` int(4) NOT NULL DEFAULT '-1',
  `cCacheFullPageContentOverrideLifetime` varchar(32) NOT NULL DEFAULT '0',
  `cCacheFullPageContentLifetimeCustom` int(10) unsigned NOT NULL DEFAULT '0',
  `cIsSystemPage` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cID`),
  KEY `cParentID` (`cParentID`),
  KEY `cIsActive` (`cIsActive`),
  KEY `cCheckedOutUID` (`cCheckedOutUID`),
  KEY `uID` (`uID`),
  KEY `ctID` (`ctID`),
  KEY `cPointerID` (`cPointerID`),
  KEY `cIsTemplate` (`cIsTemplate`),
  KEY `cIsSystemPage` (`cIsSystemPage`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`cID`, `ctID`, `cIsTemplate`, `uID`, `cIsCheckedOut`, `cCheckedOutUID`, `cCheckedOutDatetime`, `cCheckedOutDatetimeLastEdit`, `cPendingAction`, `cPendingActionDatetime`, `cPendingActionUID`, `cPendingActionTargetCID`, `cOverrideTemplatePermissions`, `cInheritPermissionsFromCID`, `cInheritPermissionsFrom`, `cFilename`, `cPointerID`, `cPointerExternalLink`, `cPointerExternalLinkNewWindow`, `cIsActive`, `cChildren`, `cDisplayOrder`, `cParentID`, `pkgID`, `ptID`, `cCacheFullPageContent`, `cCacheFullPageContentOverrideLifetime`, `cCacheFullPageContentLifetimeCustom`, `cIsSystemPage`) VALUES
(1, 7, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 1, 'OVERRIDE', NULL, 0, NULL, 0, 1, 14, 0, 0, 0, 3, -1, '0', 0, 0),
(2, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'OVERRIDE', '/dashboard/view.php', 0, NULL, 0, 1, 12, 0, 0, 0, 3, -1, '0', 0, 1),
(3, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/composer/view.php', 0, NULL, 0, 1, 2, 0, 2, 0, 3, -1, '0', 0, 1),
(4, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/composer/write.php', 0, NULL, 0, 1, 0, 0, 3, 0, 3, -1, '0', 0, 1),
(5, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/composer/drafts.php', 0, NULL, 0, 1, 0, 1, 3, 0, 3, -1, '0', 0, 1),
(6, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/sitemap/view.php', 0, NULL, 0, 1, 3, 1, 2, 0, 3, -1, '0', 0, 1),
(7, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/sitemap/full.php', 0, NULL, 0, 1, 0, 0, 6, 0, 3, -1, '0', 0, 1),
(8, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/sitemap/explore.php', 0, NULL, 0, 1, 0, 1, 6, 0, 3, -1, '0', 0, 1),
(9, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/sitemap/search.php', 0, NULL, 0, 1, 0, 2, 6, 0, 3, -1, '0', 0, 1),
(10, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/files/view.php', 0, NULL, 0, 1, 4, 2, 2, 0, 3, -1, '0', 0, 1),
(11, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/files/search.php', 0, NULL, 0, 1, 0, 0, 10, 0, 3, -1, '0', 0, 1),
(12, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/files/attributes.php', 0, NULL, 0, 1, 0, 1, 10, 0, 3, -1, '0', 0, 1),
(13, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/files/sets.php', 0, NULL, 0, 1, 0, 2, 10, 0, 3, -1, '0', 0, 1),
(14, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/files/add_set.php', 0, NULL, 0, 1, 0, 3, 10, 0, 3, -1, '0', 0, 1),
(15, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/users/view.php', 0, NULL, 0, 1, 5, 3, 2, 0, 3, -1, '0', 0, 1),
(16, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/users/search.php', 0, NULL, 0, 1, 0, 0, 15, 0, 3, -1, '0', 0, 1),
(17, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/users/groups.php', 0, NULL, 0, 1, 0, 1, 15, 0, 3, -1, '0', 0, 1),
(18, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/users/attributes.php', 0, NULL, 0, 1, 0, 2, 15, 0, 3, -1, '0', 0, 1),
(19, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/users/add.php', 0, NULL, 0, 1, 0, 3, 15, 0, 3, -1, '0', 0, 1),
(20, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/users/add_group.php', 0, NULL, 0, 1, 0, 4, 15, 0, 3, -1, '0', 0, 1),
(21, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/reports.php', 0, NULL, 0, 1, 4, 4, 2, 0, 3, -1, '0', 0, 1),
(22, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/reports/statistics.php', 0, NULL, 0, 1, 0, 0, 21, 0, 3, -1, '0', 0, 1),
(23, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/reports/forms.php', 0, NULL, 0, 1, 0, 1, 21, 0, 3, -1, '0', 0, 1),
(24, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/reports/surveys.php', 0, NULL, 0, 1, 0, 2, 21, 0, 3, -1, '0', 0, 1),
(25, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/reports/logs.php', 0, NULL, 0, 1, 0, 3, 21, 0, 3, -1, '0', 0, 1),
(26, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/pages/view.php', 0, NULL, 0, 1, 4, 5, 2, 0, 3, -1, '0', 0, 1),
(27, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/pages/themes/view.php', 0, NULL, 0, 1, 3, 0, 26, 0, 3, -1, '0', 0, 1),
(28, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/pages/themes/add.php', 0, NULL, 0, 1, 0, 0, 27, 0, 3, -1, '0', 0, 1),
(29, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/pages/themes/inspect.php', 0, NULL, 0, 1, 0, 1, 27, 0, 3, -1, '0', 0, 1),
(30, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/pages/themes/customize.php', 0, NULL, 0, 1, 0, 2, 27, 0, 3, -1, '0', 0, 1),
(31, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/pages/types/view.php', 0, NULL, 0, 1, 2, 1, 26, 0, 3, -1, '0', 0, 1),
(32, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/pages/types/add.php', 0, NULL, 0, 1, 0, 0, 31, 0, 3, -1, '0', 0, 1),
(33, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/pages/attributes.php', 0, NULL, 0, 1, 0, 2, 26, 0, 3, -1, '0', 0, 1),
(34, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/pages/single.php', 0, NULL, 0, 1, 0, 3, 26, 0, 3, -1, '0', 0, 1),
(35, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/blocks/view.php', 0, NULL, 0, 1, 2, 6, 2, 0, 3, -1, '0', 0, 1),
(36, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/blocks/stacks/view.php', 0, NULL, 0, 1, 1, 0, 35, 0, 3, -1, '0', 0, 1),
(37, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 37, 'OVERRIDE', '/dashboard/blocks/stacks/list/view.php', 0, NULL, 0, 1, 0, 0, 36, 0, 3, -1, '0', 0, 1),
(38, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/blocks/types/view.php', 0, NULL, 0, 1, 0, 1, 35, 0, 3, -1, '0', 0, 1),
(39, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/extend/view.php', 0, NULL, 0, 1, 5, 7, 2, 0, 3, -1, '0', 0, 1),
(40, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/news.php', 0, NULL, 0, 1, 0, 8, 2, 0, 3, -1, '0', 0, 1),
(41, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/extend/install.php', 0, NULL, 0, 1, 0, 0, 39, 0, 3, -1, '0', 0, 1),
(42, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/extend/update.php', 0, NULL, 0, 1, 0, 1, 39, 0, 3, -1, '0', 0, 1),
(43, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/extend/connect.php', 0, NULL, 0, 1, 0, 2, 39, 0, 3, -1, '0', 0, 1),
(44, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/extend/themes.php', 0, NULL, 0, 1, 0, 3, 39, 0, 3, -1, '0', 0, 1),
(45, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/extend/add-ons.php', 0, NULL, 0, 1, 0, 4, 39, 0, 3, -1, '0', 0, 1),
(46, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/view.php', 0, NULL, 0, 1, 9, 9, 2, 0, 3, -1, '0', 0, 1),
(47, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/basics/view.php', 0, NULL, 0, 1, 6, 0, 46, 0, 3, -1, '0', 0, 1),
(48, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/basics/site_name.php', 0, NULL, 0, 1, 0, 0, 47, 0, 3, -1, '0', 0, 1),
(49, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/basics/icons.php', 0, NULL, 0, 1, 0, 1, 47, 0, 3, -1, '0', 0, 1),
(50, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/basics/editor.php', 0, NULL, 0, 1, 0, 2, 47, 0, 3, -1, '0', 0, 1),
(51, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/basics/multilingual/view.php', 0, NULL, 0, 1, 0, 3, 47, 0, 3, -1, '0', 0, 1),
(52, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/basics/timezone.php', 0, NULL, 0, 1, 0, 4, 47, 0, 3, -1, '0', 0, 1),
(53, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/basics/interface.php', 0, NULL, 0, 1, 0, 5, 47, 0, 3, -1, '0', 0, 1),
(54, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/seo/view.php', 0, NULL, 0, 1, 4, 1, 46, 0, 3, -1, '0', 0, 1),
(55, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/seo/urls.php', 0, NULL, 0, 1, 0, 0, 54, 0, 3, -1, '0', 0, 1),
(56, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/seo/tracking_codes.php', 0, NULL, 0, 1, 0, 1, 54, 0, 3, -1, '0', 0, 1),
(57, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/seo/statistics.php', 0, NULL, 0, 1, 0, 2, 54, 0, 3, -1, '0', 0, 1),
(58, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/seo/search_index.php', 0, NULL, 0, 1, 0, 3, 54, 0, 3, -1, '0', 0, 1),
(59, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/optimization/view.php', 0, NULL, 0, 1, 3, 2, 46, 0, 3, -1, '0', 0, 1),
(60, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/optimization/cache.php', 0, NULL, 0, 1, 0, 0, 59, 0, 3, -1, '0', 0, 1),
(61, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/optimization/clear_cache.php', 0, NULL, 0, 1, 0, 1, 59, 0, 3, -1, '0', 0, 1),
(62, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/optimization/jobs.php', 0, NULL, 0, 1, 0, 2, 59, 0, 3, -1, '0', 0, 1),
(63, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/permissions/view.php', 0, NULL, 0, 1, 8, 3, 46, 0, 3, -1, '0', 0, 1),
(64, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/permissions/site.php', 0, NULL, 0, 1, 0, 0, 63, 0, 3, -1, '0', 0, 1),
(65, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/permissions/files.php', 0, NULL, 0, 1, 0, 1, 63, 0, 3, -1, '0', 0, 1),
(66, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/permissions/file_types.php', 0, NULL, 0, 1, 0, 2, 63, 0, 3, -1, '0', 0, 1),
(67, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/permissions/tasks.php', 0, NULL, 0, 1, 0, 3, 63, 0, 3, -1, '0', 0, 1),
(68, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/permissions/ip_blacklist.php', 0, NULL, 0, 1, 0, 4, 63, 0, 3, -1, '0', 0, 1),
(69, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/permissions/captcha.php', 0, NULL, 0, 1, 0, 5, 63, 0, 3, -1, '0', 0, 1),
(70, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/permissions/antispam.php', 0, NULL, 0, 1, 0, 6, 63, 0, 3, -1, '0', 0, 1),
(71, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/permissions/maintenance_mode.php', 0, NULL, 0, 1, 0, 7, 63, 0, 3, -1, '0', 0, 1),
(72, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/registration/view.php', 0, NULL, 0, 1, 3, 4, 46, 0, 3, -1, '0', 0, 1),
(73, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/registration/postlogin.php', 0, NULL, 0, 1, 0, 0, 72, 0, 3, -1, '0', 0, 1),
(74, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/registration/profiles.php', 0, NULL, 0, 1, 0, 1, 72, 0, 3, -1, '0', 0, 1),
(75, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/registration/public_registration.php', 0, NULL, 0, 1, 0, 2, 72, 0, 3, -1, '0', 0, 1),
(76, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/mail/view.php', 0, NULL, 0, 1, 2, 5, 46, 0, 3, -1, '0', 0, 1),
(77, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/mail/method.php', 0, NULL, 0, 1, 0, 0, 76, 0, 3, -1, '0', 0, 1),
(78, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/mail/importers.php', 0, NULL, 0, 1, 0, 1, 76, 0, 3, -1, '0', 0, 1),
(79, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/attributes/view.php', 0, NULL, 0, 1, 2, 6, 46, 0, 3, -1, '0', 0, 1),
(80, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/attributes/sets.php', 0, NULL, 0, 1, 0, 0, 79, 0, 3, -1, '0', 0, 1),
(81, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/attributes/types.php', 0, NULL, 0, 1, 0, 1, 79, 0, 3, -1, '0', 0, 1),
(82, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/environment/view.php', 0, NULL, 0, 1, 4, 7, 46, 0, 3, -1, '0', 0, 1),
(83, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/environment/info.php', 0, NULL, 0, 1, 0, 0, 82, 0, 3, -1, '0', 0, 1),
(84, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/environment/debug.php', 0, NULL, 0, 1, 0, 1, 82, 0, 3, -1, '0', 0, 1),
(85, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/environment/logging.php', 0, NULL, 0, 1, 0, 2, 82, 0, 3, -1, '0', 0, 1),
(86, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/environment/file_storage_locations.php', 0, NULL, 0, 1, 0, 3, 82, 0, 3, -1, '0', 0, 1),
(87, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/backup_restore/view.php', 0, NULL, 0, 1, 3, 8, 46, 0, 3, -1, '0', 0, 1),
(88, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/backup_restore/backup.php', 0, NULL, 0, 1, 0, 0, 87, 0, 3, -1, '0', 0, 1),
(89, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/backup_restore/update.php', 0, NULL, 0, 1, 0, 1, 87, 0, 3, -1, '0', 0, 1),
(90, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/system/backup_restore/database.php', 0, NULL, 0, 1, 0, 2, 87, 0, 3, -1, '0', 0, 1),
(91, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', '/dashboard/pages/types/composer.php', 0, NULL, 0, 1, 0, 1, 31, 0, 3, -1, '0', 0, 1),
(92, 1, 1, NULL, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 0, 'PARENT', NULL, 0, NULL, 0, 1, 0, 0, 0, 0, 0, -1, '0', 0, 0),
(93, 2, 1, NULL, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 0, 'PARENT', NULL, 0, NULL, 0, 1, 0, 0, 0, 0, 0, -1, '0', 0, 0),
(94, 3, 1, NULL, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 0, 'PARENT', NULL, 0, NULL, 0, 1, 0, 0, 0, 0, 0, -1, '0', 0, 0),
(95, 2, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', NULL, 0, NULL, 0, 1, 0, 10, 2, 0, 3, -1, '0', 0, 1),
(96, 3, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 2, 'PARENT', NULL, 0, NULL, 0, 1, 0, 11, 2, 0, 3, -1, '0', 0, 1),
(97, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 1, 'PARENT', '/!drafts/view.php', 0, NULL, 0, 1, 0, 0, 0, 0, 3, -1, '0', 0, 1),
(98, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 1, 'PARENT', '/!trash/view.php', 0, NULL, 0, 1, 0, 0, 0, 0, 3, -1, '0', 0, 1),
(99, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 1, 'PARENT', '/!stacks/view.php', 0, NULL, 0, 1, 3, 0, 0, 0, 3, -1, '0', 0, 1),
(100, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 100, 'OVERRIDE', '/login.php', 0, NULL, 0, 1, 0, 0, 0, 0, 3, -1, '0', 0, 1),
(101, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 101, 'OVERRIDE', '/register.php', 0, NULL, 0, 1, 0, 0, 0, 0, 3, -1, '0', 0, 1),
(102, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 1, 'PARENT', '/profile/view.php', 0, NULL, 0, 1, 4, 0, 1, 0, 3, -1, '0', 0, 1),
(103, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 1, 'PARENT', '/profile/edit.php', 0, NULL, 0, 1, 0, 0, 102, 0, 3, -1, '0', 0, 1),
(104, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 1, 'PARENT', '/profile/avatar.php', 0, NULL, 0, 1, 0, 1, 102, 0, 3, -1, '0', 0, 1),
(105, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 1, 'PARENT', '/profile/messages.php', 0, NULL, 0, 1, 0, 2, 102, 0, 3, -1, '0', 0, 1),
(106, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 1, 'PARENT', '/profile/friends.php', 0, NULL, 0, 1, 0, 3, 102, 0, 3, -1, '0', 0, 1),
(107, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 1, 'PARENT', '/page_not_found.php', 0, NULL, 0, 1, 0, 1, 0, 0, 3, -1, '0', 0, 1),
(108, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 1, 'PARENT', '/page_forbidden.php', 0, NULL, 0, 1, 0, 1, 0, 0, 3, -1, '0', 0, 1),
(109, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 1, 'PARENT', '/download_file.php', 0, NULL, 0, 1, 0, 1, 1, 0, 3, -1, '0', 0, 1),
(110, 0, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 1, 'PARENT', '/members.php', 0, NULL, 0, 1, 0, 2, 1, 0, 3, -1, '0', 0, 1),
(111, 1, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 1, 'PARENT', NULL, 0, NULL, 0, 1, 0, 0, 99, 0, 3, -1, '0', 0, 1),
(112, 1, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 1, 'PARENT', NULL, 0, NULL, 0, 1, 0, 1, 99, 0, 3, -1, '0', 0, 1),
(113, 1, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 1, 'PARENT', NULL, 0, NULL, 0, 1, 0, 2, 99, 0, 3, -1, '0', 0, 1),
(114, 4, 1, NULL, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 0, 'PARENT', NULL, 0, NULL, 0, 1, 0, 0, 0, 0, 0, -1, '0', 0, 0),
(115, 5, 1, NULL, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 0, 'PARENT', NULL, 0, NULL, 0, 1, 0, 0, 0, 0, 0, -1, '0', 0, 0),
(116, 6, 1, NULL, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 0, 'PARENT', NULL, 0, NULL, 0, 1, 0, 0, 0, 0, 0, -1, '0', 0, 0),
(117, 7, 1, NULL, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 0, 'PARENT', NULL, 0, NULL, 0, 1, 0, 0, 0, 0, 0, -1, '0', 0, 0),
(118, 6, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 1, 'PARENT', NULL, 0, NULL, 0, 1, 2, 3, 1, 0, 3, -1, '0', 0, 0),
(119, 7, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 1, 'PARENT', NULL, 0, NULL, 0, 1, 2, 4, 1, 0, 3, -1, '0', 0, 0),
(120, 7, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 1, 'PARENT', NULL, 0, NULL, 0, 1, 0, 5, 1, 0, 3, -1, '0', 0, 0),
(121, 6, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 1, 'PARENT', NULL, 0, NULL, 0, 1, 0, 0, 118, 0, 3, -1, '0', 0, 0),
(122, 7, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 1, 'PARENT', NULL, 0, NULL, 0, 1, 0, 1, 118, 0, 3, -1, '0', 0, 0),
(123, 7, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 1, 'PARENT', NULL, 0, NULL, 0, 1, 0, 0, 119, 0, 3, -1, '0', 0, 0),
(124, 4, 0, 1, 0, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 1, 1, 'PARENT', NULL, 0, NULL, 0, 1, 0, 1, 119, 0, 3, -1, '0', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pagesearchindex`
--

CREATE TABLE IF NOT EXISTS `pagesearchindex` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `content` text,
  `cName` varchar(255) DEFAULT NULL,
  `cDescription` text,
  `cPath` text,
  `cDatePublic` datetime DEFAULT NULL,
  `cDateLastIndexed` datetime DEFAULT NULL,
  `cDateLastSitemapped` datetime DEFAULT NULL,
  `cRequiresReindex` tinyint(1) unsigned DEFAULT '0',
  PRIMARY KEY (`cID`),
  KEY `cDateLastIndexed` (`cDateLastIndexed`),
  KEY `cDateLastSitemapped` (`cDateLastSitemapped`),
  KEY `cRequiresReindex` (`cRequiresReindex`),
  FULLTEXT KEY `cName` (`cName`),
  FULLTEXT KEY `cDescription` (`cDescription`),
  FULLTEXT KEY `content` (`content`),
  FULLTEXT KEY `content2` (`cName`,`cDescription`,`content`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pagesearchindex`
--

INSERT INTO `pagesearchindex` (`cID`, `content`, `cName`, `cDescription`, `cPath`, `cDatePublic`, `cDateLastIndexed`, `cDateLastSitemapped`, `cRequiresReindex`) VALUES
(3, '', 'Composer', 'Write for your site.', '/dashboard/composer', NOW(), NOW(), NULL, 0),
(4, '', 'Write', '', '/dashboard/composer/write', NOW(), NOW(), NULL, 0),
(5, '', 'Drafts', '', '/dashboard/composer/drafts', NOW(), NOW(), NULL, 0),
(6, '', 'Sitemap', 'Whole world at a glance.', '/dashboard/sitemap', NOW(), NOW(), NULL, 0),
(7, '', 'Full Sitemap', '', '/dashboard/sitemap/full', NOW(), NOW(), NULL, 0),
(8, '', 'Flat View', '', '/dashboard/sitemap/explore', NOW(), NOW(), NULL, 0),
(9, '', 'Page Search', '', '/dashboard/sitemap/search', NOW(), NOW(), NULL, 0),
(11, '', 'File Manager', '', '/dashboard/files/search', NOW(), NOW(), NULL, 0),
(12, '', 'Attributes', '', '/dashboard/files/attributes', NOW(), NOW(), NULL, 0),
(13, '', 'File Sets', '', '/dashboard/files/sets', NOW(), NOW(), NULL, 0),
(14, '', 'Add File Set', '', '/dashboard/files/add_set', NOW(), NOW(), NULL, 0),
(15, '', 'Members', 'Add and manage the user accounts and groups on your website.', '/dashboard/users', NOW(), NOW(), NULL, 0),
(16, '', 'Search Users', '', '/dashboard/users/search', NOW(), NOW(), NULL, 0),
(17, '', 'User Groups', '', '/dashboard/users/groups', NOW(), NOW(), NULL, 0),
(18, '', 'Attributes', '', '/dashboard/users/attributes', NOW(), NOW(), NULL, 0),
(19, '', 'Add User', '', '/dashboard/users/add', NOW(), NOW(), NULL, 0),
(20, '', 'Add Group', '', '/dashboard/users/add_group', NOW(), NOW(), NULL, 0),
(21, '', 'Reports', 'Get data from forms and logs.', '/dashboard/reports', NOW(), NOW(), NULL, 0),
(22, '', 'Statistics', 'View your site activity.', '/dashboard/reports/statistics', NOW(), NOW(), NULL, 0),
(23, '', 'Form Results', 'Get submission data.', '/dashboard/reports/forms', NOW(), NOW(), NULL, 0),
(24, '', 'Surveys', '', '/dashboard/reports/surveys', NOW(), NOW(), NULL, 0),
(25, '', 'Logs', '', '/dashboard/reports/logs', NOW(), NOW(), NULL, 0),
(26, '', 'Pages & Themes', 'Reskin your site.', '/dashboard/pages', NOW(), NOW(), NULL, 0),
(27, '', 'Themes', 'Reskin your site.', '/dashboard/pages/themes', NOW(), NOW(), NULL, 0),
(28, '', 'Add', '', '/dashboard/pages/themes/add', NOW(), NOW(), NULL, 0),
(30, '', 'Customize', '', '/dashboard/pages/themes/customize', NOW(), NOW(), NULL, 0),
(31, '', 'Page Types', 'What goes in your site.', '/dashboard/pages/types', NOW(), NOW(), NULL, 0),
(33, '', 'Attributes', '', '/dashboard/pages/attributes', NOW(), NOW(), NULL, 0),
(37, '', 'Stack List', '', '/dashboard/blocks/stacks/list', NOW(), NOW(), NULL, 0),
(39, '', 'Extend concrete5', 'Connect to the concrete5 marketplace, install custom add-ons, and download updates for marketplace add-ons and themes.', '/dashboard/extend', NOW(), NOW(), NULL, 0),
(40, '', 'Dashboard', '', '/dashboard/news', NOW(), NOW(), NULL, 0),
(41, '', 'Add Functionality', 'Install add-ons & themes.', '/dashboard/extend/install', NOW(), NOW(), NULL, 0),
(42, '', 'Update Add-Ons', 'Update your installed packages.', '/dashboard/extend/update', NOW(), NOW(), NULL, 0),
(43, '', 'Connect to the Community', 'Connect to the concrete5 community.', '/dashboard/extend/connect', NOW(), NOW(), NULL, 0),
(44, '', 'Get More Themes', 'Download themes from concrete5.org.', '/dashboard/extend/themes', NOW(), NOW(), NULL, 0),
(45, '', 'Get More Add-Ons', 'Download add-ons from concrete5.org.', '/dashboard/extend/add-ons', NOW(), NOW(), NULL, 0),
(46, '', 'System & Settings', 'Secure and setup your site.', '/dashboard/system', NOW(), NOW(), NULL, 0),
(48, '', 'Site Name', '', '/dashboard/system/basics/site_name', NOW(), NOW(), NULL, 0),
(49, '', 'Bookmark Icons', 'Bookmark icon and mobile home screen icon setup.', '/dashboard/system/basics/icons', NOW(), NOW(), NULL, 0),
(50, '', 'Rich Text Editor', '', '/dashboard/system/basics/editor', NOW(), NOW(), NULL, 0),
(51, '', 'Languages', '', '/dashboard/system/basics/multilingual', NOW(), NOW(), NULL, 0),
(52, '', 'Time Zone', '', '/dashboard/system/basics/timezone', NOW(), NOW(), NULL, 0),
(53, '', 'Interface Preferences', '', '/dashboard/system/basics/interface', NOW(), NOW(), NULL, 0),
(55, '', 'Pretty URLs', '', '/dashboard/system/seo/urls', NOW(), NOW(), NULL, 0),
(56, '', 'Tracking Codes', '', '/dashboard/system/seo/tracking_codes', NOW(), NOW(), NULL, 0),
(57, '', 'Statistics', '', '/dashboard/system/seo/statistics', NOW(), NOW(), NULL, 0),
(58, '', 'Search Index', '', '/dashboard/system/seo/search_index', NOW(), NOW(), NULL, 0),
(60, '', 'Cache & Speed Settings', '', '/dashboard/system/optimization/cache', NOW(), NOW(), NULL, 0),
(61, '', 'Clear Cache', '', '/dashboard/system/optimization/clear_cache', NOW(), NOW(), NULL, 0),
(62, '', 'Automated Jobs', '', '/dashboard/system/optimization/jobs', NOW(), NOW(), NULL, 0),
(64, '', 'Site Access', '', '/dashboard/system/permissions/site', NOW(), NOW(), NULL, 0),
(65, '', 'File Manager Permissions', '', '/dashboard/system/permissions/files', NOW(), NOW(), NULL, 0),
(66, '', 'Allowed File Types', '', '/dashboard/system/permissions/file_types', NOW(), NOW(), NULL, 0),
(67, '', 'Task Permissions', '', '/dashboard/system/permissions/tasks', NOW(), NOW(), NULL, 0),
(68, '', 'IP Blacklist', '', '/dashboard/system/permissions/ip_blacklist', NOW(), NOW(), NULL, 0),
(69, '', 'Captcha Setup', '', '/dashboard/system/permissions/captcha', NOW(), NOW(), NULL, 0),
(70, '', 'Spam Control', '', '/dashboard/system/permissions/antispam', NOW(), NOW(), NULL, 0),
(71, '', 'Maintenance Mode', '', '/dashboard/system/permissions/maintenance_mode', NOW(), NOW(), NULL, 0),
(73, '', 'Login Destination', '', '/dashboard/system/registration/postlogin', NOW(), NOW(), NULL, 0),
(74, '', 'Public Profiles', '', '/dashboard/system/registration/profiles', NOW(), NOW(), NULL, 0),
(75, '', 'Public Registration', '', '/dashboard/system/registration/public_registration', NOW(), NOW(), NULL, 0),
(76, '', 'Email', 'Control how your site send and processes mail.', '/dashboard/system/mail', NOW(), NOW(), NULL, 0),
(77, '', 'SMTP Method', '', '/dashboard/system/mail/method', NOW(), NOW(), NULL, 0),
(78, '', 'Email Importers', '', '/dashboard/system/mail/importers', NOW(), NOW(), NULL, 0),
(79, '', 'Attributes', 'Setup attributes for pages, users, files and more.', '/dashboard/system/attributes', NOW(), NOW(), NULL, 0),
(82, '', 'Environment', 'Advanced settings for web developers.', '/dashboard/system/environment', NOW(), NOW(), NULL, 0),
(83, '', 'Environment Information', '', '/dashboard/system/environment/info', NOW(), NOW(), NULL, 0),
(84, '', 'Debug Settings', '', '/dashboard/system/environment/debug', NOW(), NOW(), NULL, 0),
(85, '', 'Logging Settings', '', '/dashboard/system/environment/logging', NOW(), NOW(), NULL, 0),
(86, '', 'File Storage Locations', '', '/dashboard/system/environment/file_storage_locations', NOW(), NOW(), NULL, 0),
(89, '', 'Update concrete5', '', '/dashboard/system/backup_restore/update', NOW(), NOW(), NULL, 0),
(96, '	Welcome to concrete5.\n						It''s easy to edit content and add pages using in-context editing. \n						 \n							Building Your Own Site\n							 Editing with concrete5 is a breeze. Just point and click to make changes. \n							 \n							 Editor''s Guide \n							  \n							Developing Applications\n							 If you�re comfortable in PHP concrete5 should be a breeze to learn. Take a few moments to understand the architecture. \n							 Developer''s Guide \n							  \n							Designing Websites\n							 Good with CSS and HTML? You can easily theme anything with concrete5. \n							 \n							 Designer''s Guide \n							  \n						\n						Business Background\n						 Worried about license structures, white-labeling or why concrete5 is a good choice for your agency? \n						 Executive''s Guide \n						  ', 'Welcome to concrete5', 'Learn about how to use concrete5, how to develop for concrete5, and get general help.', '/dashboard/welcome', NOW(), NOW(), NULL, 0),
(95, '', 'Customize Dashboard Home', '', '/dashboard/home', NOW(), NOW(), NULL, 0),
(1, 'Welcome to concrete5 - an Open Source CMS Sidebar  Everything about concrete5 is completely customizable through the CMS. This is a separate area from the main content on the homepage. You can&nbsp;drag and drop blocks&nbsp;like this around your layout.  Welcome to concrete5!\n                                         Content Management is easy with concrete5''s in-context editing. Just login and you can change things as you browse your site. \n                                         You can watch videos and learn how to: \n                                        \n                                        Edit&nbsp;this page.\n                                        Add a new page.\n                                        Add some basic functionality, like&nbsp;a Form.\n                                        Finding &amp; adding&nbsp;more functionality and themes.\n                                        \n                                         We''ve taken the liberty to build out the rest of this site with some sample content that will help you learn concrete5. Wander around a bit, or click Dashboard to get to the&nbsp;Sitemap and quickly delete the parts you don''t want.  ', 'Home', '', NULL, NOW(), NOW(), NULL, 0),
(118, 'About Us Learn More\n																 Visit&nbsp;concrete5.org&nbsp;to learn more from the&nbsp;community&nbsp;and the&nbsp;documentation. You can also browse our&nbsp;marketplace&nbsp;for more&nbsp;add-ons&nbsp;and&nbsp;themes&nbsp;to quickly build the site you really need.&nbsp; \n																&nbsp;\n																Getting Help\n																 You can get free help in the forums and post for free to the&nbsp;jobs board.&nbsp; \n																 You can also pay the concrete5 team of developers to help with&nbsp;any problem&nbsp;you run into. We offer training courses&nbsp;and&nbsp;hosting packages, just let us know how we can help.  ', 'About', '', '/about', NOW(), NOW(), NULL, 0),
(122, 'Guestbook ', 'Guestbook', '', '/about/guestbook', NOW(), NOW(), NULL, 0),
(121, 'Contact Us Contact Us\n									 Building a form is easy to do. Learn how to add a form block.  ', 'Contact Us', '', '/about/contact-us', NOW(), NOW(), NULL, 0),
(120, 'Sitemap Site Map ', 'Search', '', '/search', NOW(), NOW(), NULL, 0),
(119, 'Tags ', 'Blog', '', '/blog', NOW(), NOW(), NULL, 0),
(124, ' Here is some sample content! I''m writing it using composer!  ', 'Hello World', 'This is my first blog post!', '/blog/hello-world', NOW(), NOW(), NULL, 0),
(123, '', 'Blog Archives', '', '/blog/blog-archives', NOW(), NOW(), NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pagestatistics`
--

CREATE TABLE IF NOT EXISTS `pagestatistics` (
  `pstID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `date` date DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `uID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`pstID`),
  KEY `cID` (`cID`),
  KEY `date` (`date`),
  KEY `uID` (`uID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `pagestatistics`
--

INSERT INTO `pagestatistics` (`pstID`, `cID`, `date`, `timestamp`, `uID`) VALUES
(1, 1, '2012-07-12', '2012-07-12 14:46:46', 1),
(2, 96, '2012-07-12', '2012-07-12 14:46:49', 1),
(3, 27, '2012-07-12', '2012-07-12 14:47:06', 1),
(4, 27, '2012-07-12', '2012-07-12 14:47:10', 1),
(5, 27, '2012-07-12', '2012-07-12 14:47:14', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pagethemes`
--

CREATE TABLE IF NOT EXISTS `pagethemes` (
  `ptID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ptHandle` varchar(64) NOT NULL,
  `ptName` varchar(255) DEFAULT NULL,
  `ptDescription` text,
  `pkgID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ptID`),
  UNIQUE KEY `ptHandle` (`ptHandle`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `pagethemes`
--

INSERT INTO `pagethemes` (`ptID`, `ptHandle`, `ptName`, `ptDescription`, `pkgID`) VALUES
(1, 'default', 'Plain Yogurt', 'Plain Yogurt is concrete5''s default theme.', 0),
(2, 'greensalad', 'Green Salad Theme', 'This is concrete5''s Green Salad site theme.', 0),
(3, 'dark_chocolate', 'Dark Chocolate', 'Dark Chocolate is concrete5''s default theme in black.', 0),
(4, 'greek_yogurt', 'Greek Yogurt', 'An elegant theme for concrete5.', 0);

-- --------------------------------------------------------

--
-- Table structure for table `pagethemestyles`
--

CREATE TABLE IF NOT EXISTS `pagethemestyles` (
  `ptID` int(10) unsigned NOT NULL DEFAULT '0',
  `ptsHandle` varchar(128) NOT NULL,
  `ptsValue` longtext,
  `ptsType` varchar(32) NOT NULL,
  PRIMARY KEY (`ptID`,`ptsHandle`,`ptsType`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pagethemestyles`
--


-- --------------------------------------------------------

--
-- Table structure for table `pagetypeattributes`
--

CREATE TABLE IF NOT EXISTS `pagetypeattributes` (
  `ctID` int(10) unsigned NOT NULL DEFAULT '0',
  `akID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ctID`,`akID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pagetypeattributes`
--


-- --------------------------------------------------------

--
-- Table structure for table `pagetypes`
--

CREATE TABLE IF NOT EXISTS `pagetypes` (
  `ctID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ctHandle` varchar(32) NOT NULL,
  `ctIcon` varchar(128) DEFAULT NULL,
  `ctName` varchar(90) NOT NULL,
  `ctIsInternal` tinyint(1) NOT NULL DEFAULT '0',
  `pkgID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ctID`),
  UNIQUE KEY `ctHandle` (`ctHandle`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `pagetypes`
--

INSERT INTO `pagetypes` (`ctID`, `ctHandle`, `ctIcon`, `ctName`, `ctIsInternal`, `pkgID`) VALUES
(1, 'core_stack', 'main.png', 'Stack', 1, 0),
(2, 'dashboard_primary_five', 'main.png', 'Dashboard Primary + Five', 1, 0),
(3, 'dashboard_header_four_col', 'main.png', 'Dashboard Header + Four Column', 1, 0),
(4, 'blog_entry', 'template1.png', 'Blog Entry', 0, 0),
(5, 'full', 'main.png', 'Full', 0, 0),
(6, 'left_sidebar', 'template1.png', 'Left Sidebar', 0, 0),
(7, 'right_sidebar', 'right_sidebar.png', 'Right Sidebar', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pilecontents`
--

CREATE TABLE IF NOT EXISTS `pilecontents` (
  `pcID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pID` int(10) unsigned NOT NULL DEFAULT '0',
  `itemID` int(10) unsigned NOT NULL DEFAULT '0',
  `itemType` varchar(64) NOT NULL,
  `quantity` int(10) unsigned NOT NULL DEFAULT '1',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `displayOrder` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`pcID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `pilecontents`
--


-- --------------------------------------------------------

--
-- Table structure for table `piles`
--

CREATE TABLE IF NOT EXISTS `piles` (
  `pID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uID` int(10) unsigned DEFAULT NULL,
  `isDefault` tinyint(1) NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(255) DEFAULT NULL,
  `state` varchar(64) NOT NULL,
  PRIMARY KEY (`pID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `piles`
--


-- --------------------------------------------------------

--
-- Table structure for table `signuprequests`
--

CREATE TABLE IF NOT EXISTS `signuprequests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipFrom` int(10) unsigned NOT NULL DEFAULT '0',
  `date_access` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `index_ipFrom` (`ipFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `signuprequests`
--


-- --------------------------------------------------------

--
-- Table structure for table `stacks`
--

CREATE TABLE IF NOT EXISTS `stacks` (
  `stID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `stName` varchar(255) NOT NULL,
  `stType` int(1) unsigned NOT NULL DEFAULT '0',
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`stID`),
  KEY `stType` (`stType`),
  KEY `stName` (`stName`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `stacks`
--

INSERT INTO `stacks` (`stID`, `stName`, `stType`, `cID`) VALUES
(1, 'Header Nav', 20, 111),
(2, 'Side Nav', 0, 112),
(3, 'Site Name', 20, 113);

-- --------------------------------------------------------

--
-- Table structure for table `systemantispamlibraries`
--

CREATE TABLE IF NOT EXISTS `systemantispamlibraries` (
  `saslHandle` varchar(64) NOT NULL,
  `saslName` varchar(255) DEFAULT NULL,
  `saslIsActive` int(1) NOT NULL DEFAULT '0',
  `pkgID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`saslHandle`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `systemantispamlibraries`
--


-- --------------------------------------------------------

--
-- Table structure for table `systemcaptchalibraries`
--

CREATE TABLE IF NOT EXISTS `systemcaptchalibraries` (
  `sclHandle` varchar(64) NOT NULL,
  `sclName` varchar(255) DEFAULT NULL,
  `sclIsActive` int(1) NOT NULL DEFAULT '0',
  `pkgID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`sclHandle`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `systemcaptchalibraries`
--

INSERT INTO `systemcaptchalibraries` (`sclHandle`, `sclName`, `sclIsActive`, `pkgID`) VALUES
('securimage', 'SecurImage (Default)', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `systemnotifications`
--

CREATE TABLE IF NOT EXISTS `systemnotifications` (
  `snID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `snTypeID` int(3) unsigned NOT NULL DEFAULT '0',
  `snURL` text,
  `snURL2` text,
  `snDateTime` datetime NOT NULL,
  `snIsArchived` int(1) NOT NULL DEFAULT '0',
  `snIsNew` int(1) NOT NULL DEFAULT '0',
  `snTitle` varchar(255) DEFAULT NULL,
  `snDescription` text,
  `snBody` text,
  PRIMARY KEY (`snID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `systemnotifications`
--


-- --------------------------------------------------------

--
-- Table structure for table `taskpermissions`
--

CREATE TABLE IF NOT EXISTS `taskpermissions` (
  `tpID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tpHandle` varchar(255) DEFAULT NULL,
  `tpName` varchar(255) DEFAULT NULL,
  `tpDescription` text,
  `pkgID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`tpID`),
  UNIQUE KEY `tpHandle` (`tpHandle`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `taskpermissions`
--

INSERT INTO `taskpermissions` (`tpID`, `tpHandle`, `tpName`, `tpDescription`, `pkgID`) VALUES
(1, 'access_task_permissions', 'Change Task Permissions', '', 0),
(2, 'access_sitemap', 'Access Sitemap and Page Search', '', 0),
(3, 'access_user_search', 'Access User Search', '', 0),
(4, 'access_group_search', 'Access Group Search', '', 0),
(5, 'access_page_defaults', 'Change Content on Page Type Default Pages', '', 0),
(6, 'backup', 'Perform Full Database Backups', '', 0),
(7, 'sudo', 'Sign in as User', '', 0),
(8, 'uninstall_packages', 'Uninstall Packages', '', 0),
(9, 'install_packages', 'Install Packages and Connect to the Marketplace', '', 0),
(10, 'delete_user', 'Delete Users', '', 0),
(11, 'view_newsflow', 'View Newsflow Updates in an Overlay', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `taskpermissionusergroups`
--

CREATE TABLE IF NOT EXISTS `taskpermissionusergroups` (
  `tpID` int(10) unsigned NOT NULL DEFAULT '0',
  `gID` int(10) unsigned NOT NULL DEFAULT '0',
  `uID` int(10) unsigned NOT NULL DEFAULT '0',
  `canRead` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tpID`,`gID`,`uID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `taskpermissionusergroups`
--

INSERT INTO `taskpermissionusergroups` (`tpID`, `gID`, `uID`, `canRead`) VALUES
(1, 3, 0, 1),
(2, 3, 0, 1),
(3, 3, 0, 1),
(4, 3, 0, 1),
(5, 3, 0, 1),
(6, 3, 0, 1),
(8, 3, 0, 1),
(9, 3, 0, 1),
(10, 3, 0, 1),
(11, 3, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `userattributekeys`
--

CREATE TABLE IF NOT EXISTS `userattributekeys` (
  `akID` int(10) unsigned NOT NULL,
  `uakProfileDisplay` tinyint(1) NOT NULL DEFAULT '0',
  `uakMemberListDisplay` tinyint(1) NOT NULL DEFAULT '0',
  `uakProfileEdit` tinyint(1) NOT NULL DEFAULT '1',
  `uakProfileEditRequired` tinyint(1) NOT NULL DEFAULT '0',
  `uakRegisterEdit` tinyint(1) NOT NULL DEFAULT '0',
  `uakRegisterEditRequired` tinyint(1) NOT NULL DEFAULT '0',
  `displayOrder` int(10) unsigned DEFAULT '0',
  `uakIsActive` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`akID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `userattributekeys`
--

INSERT INTO `userattributekeys` (`akID`, `uakProfileDisplay`, `uakMemberListDisplay`, `uakProfileEdit`, `uakProfileEditRequired`, `uakRegisterEdit`, `uakRegisterEditRequired`, `displayOrder`, `uakIsActive`) VALUES
(9, 0, 0, 1, 0, 1, 0, 1, 1),
(10, 0, 0, 1, 0, 1, 0, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `userattributevalues`
--

CREATE TABLE IF NOT EXISTS `userattributevalues` (
  `uID` int(10) unsigned NOT NULL DEFAULT '0',
  `akID` int(10) unsigned NOT NULL DEFAULT '0',
  `avID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`uID`,`akID`,`avID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `userattributevalues`
--


-- --------------------------------------------------------

--
-- Table structure for table `userbannedips`
--

CREATE TABLE IF NOT EXISTS `userbannedips` (
  `ipFrom` int(10) unsigned NOT NULL DEFAULT '0',
  `ipTo` int(10) unsigned NOT NULL DEFAULT '0',
  `banCode` int(1) unsigned NOT NULL DEFAULT '1',
  `expires` int(10) unsigned NOT NULL DEFAULT '0',
  `isManual` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ipFrom`,`ipTo`),
  KEY `ipFrom` (`ipFrom`),
  KEY `ipTo` (`ipTo`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `userbannedips`
--


-- --------------------------------------------------------

--
-- Table structure for table `usergroups`
--

CREATE TABLE IF NOT EXISTS `usergroups` (
  `uID` int(10) unsigned NOT NULL DEFAULT '0',
  `gID` int(10) unsigned NOT NULL DEFAULT '0',
  `ugEntered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`uID`,`gID`),
  KEY `uID` (`uID`),
  KEY `gID` (`gID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `usergroups`
--


-- --------------------------------------------------------

--
-- Table structure for table `useropenids`
--

CREATE TABLE IF NOT EXISTS `useropenids` (
  `uID` int(10) unsigned NOT NULL,
  `uOpenID` varchar(255) NOT NULL,
  PRIMARY KEY (`uOpenID`),
  KEY `uID` (`uID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `userprivatemessages` (
  `msgID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uAuthorID` int(10) unsigned NOT NULL DEFAULT '0',
  `msgDateCreated` datetime NOT NULL,
  `msgSubject` varchar(255) NOT NULL,
  `msgBody` text,
  `uToID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`msgID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `userprivatemessagesto` (
  `msgID` int(10) unsigned NOT NULL DEFAULT '0',
  `uID` int(10) unsigned NOT NULL DEFAULT '0',
  `uAuthorID` int(10) unsigned NOT NULL DEFAULT '0',
  `msgMailboxID` int(11) NOT NULL,
  `msgIsNew` int(1) NOT NULL DEFAULT '0',
  `msgIsUnread` int(1) NOT NULL DEFAULT '0',
  `msgIsReplied` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`msgID`,`uID`,`uAuthorID`),
  KEY `uID` (`uID`),
  KEY `uAuthorID` (`uAuthorID`),
  KEY `msgFolderID` (`msgMailboxID`),
  KEY `msgIsNew` (`msgIsNew`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `users` (
  `uID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uName` varchar(64) NOT NULL,
  `uEmail` varchar(64) NOT NULL,
  `uPassword` varchar(255) NOT NULL,
  `uIsActive` varchar(1) NOT NULL DEFAULT '0',
  `uIsValidated` tinyint(4) NOT NULL DEFAULT '-1',
  `uIsFullRecord` tinyint(1) NOT NULL DEFAULT '1',
  `uDateAdded` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `uHasAvatar` tinyint(1) NOT NULL DEFAULT '0',
  `uLastOnline` int(10) unsigned NOT NULL DEFAULT '0',
  `uLastLogin` int(10) unsigned NOT NULL DEFAULT '0',
  `uPreviousLogin` int(10) unsigned NOT NULL DEFAULT '0',
  `uNumLogins` int(10) unsigned NOT NULL DEFAULT '0',
  `uTimezone` varchar(255) DEFAULT NULL,
  `uDefaultLanguage` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`uID`),
  UNIQUE KEY `uName` (`uName`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;


INSERT INTO `users` (`uID`, `uName`, `uEmail`, `uPassword`, `uIsActive`, `uIsValidated`, `uIsFullRecord`, `uDateAdded`, `uHasAvatar`, `uLastOnline`, `uLastLogin`, `uPreviousLogin`, `uNumLogins`, `uTimezone`, `uDefaultLanguage`) VALUES
(1, '@@ADMIN_NAME@@', '@@ADMIN_EMAIL@@', '@@ADMIN_PASSWORD@@', '1', -1, 1, NOW(), 0, 1342084606, 1342084572, 0, 1, NULL, NULL);

CREATE TABLE IF NOT EXISTS `usersearchindexattributes` (
  `uID` int(11) unsigned NOT NULL DEFAULT '0',
  `ak_profile_private_messages_enabled` tinyint(4) DEFAULT '0',
  `ak_profile_private_messages_notification_enabled` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`uID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `usersfriends` (
  `ufID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uID` int(10) unsigned DEFAULT NULL,
  `status` varchar(64) NOT NULL,
  `friendUID` int(10) unsigned DEFAULT NULL,
  `uDateAdded` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ufID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;


CREATE TABLE IF NOT EXISTS `uservalidationhashes` (
  `uvhID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uID` int(10) unsigned DEFAULT NULL,
  `uHash` varchar(64) NOT NULL,
  `type` int(4) unsigned NOT NULL DEFAULT '0',
  `uDateGenerated` int(10) unsigned NOT NULL DEFAULT '0',
  `uDateRedeemed` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`uvhID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

