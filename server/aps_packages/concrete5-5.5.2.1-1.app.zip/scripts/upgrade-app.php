<?php

ini_set('include_path', '.');

require_once('app-util.php');
require_once('file-util.php');


$config_files = array( '/' => array( array('LocalSettings.php.in', 'LocalSettings.php'), array('AdminSettings.php.in', 'AdminSettings.php')) );

$psa_params = array (  );
$db_ids = array ( 'main' );
$web_ids = array ( '/' );
$settings_params = array ( 'admin_name', 'admin_password', 'admin_email', 'title', 'locale' );
$settings_enum_params = array ( 'locale' => array( 'en-US' => 'En', 'fr-FR' => 'Fr' ) );
$crypt_settings_params = array (  );

$psa_modify_hash = get_psa_modify_hash($psa_params);
$db_modify_hash = get_db_modify_hash($db_ids);
$settings_modify_hash = get_settings_modify_hash($settings_params);
$settings_enum_modify_hash = get_settings_enum_modify_hash($settings_enum_params);
$crypt_settings_modify_hash = get_crypt_settings_modify_hash($crypt_settings_params);

$additional_modify_hash = get_additional_modify_hash();

if(count($argv) < 2)
{
    print "Usage: configure (install | upgrade <version> | configure | remove)\n";
    exit(1);
}

function ob_file_callback($buffer)
{
  global $ob_file;
  fwrite($ob_file,$buffer);
}

$command = $argv[1];
if($command == "upgrade")
{
    if($argv[2] && $argv[3]){
        $upgrade_schema_files = array ();
        configure($config_files, $upgrade_schema_files, $db_ids, $psa_modify_hash, $db_modify_hash, $settings_modify_hash, $crypt_settings_modify_hash, $settings_enum_modify_hash, $additional_modify_hash);
        if (!chdir(get_web_dir('/'))) exit(1);
        global $IP;
        $IP = get_web_dir('/');
		$ob_file = fopen('upgrade.log','w');

		ob_start('ob_file_callback');
        require_once('maintenance/update.php');
		ob_end_flush();

        exit(0);
    }
    else{
        print "Error: upgrade version or release not specified.\n";
        exit(1);
    }
}


function upgrade_app($from_ver, $from_rel, $config_files, $db_ids, $psa_modify_hash, $db_modify_hash, $settings_modify_hash, $crypt_settings_modify_hash, $settings_enum_modify_hash, $additional_modify_hash)
{
    return;
}
?>
