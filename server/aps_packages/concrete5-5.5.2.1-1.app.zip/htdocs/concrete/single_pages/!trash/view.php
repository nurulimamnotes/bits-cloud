<?php  defined('C5_EXECUTE') or die("Access Denied.");

$this->controller->redirect('/');
exit;
