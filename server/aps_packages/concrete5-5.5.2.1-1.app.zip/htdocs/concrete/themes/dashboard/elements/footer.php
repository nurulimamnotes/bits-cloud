<?php  defined('C5_EXECUTE') or die("Access Denied."); ?>
<?php 
if ($_GET['_ccm_dashboard_external']) {
	return;
}
?>
	
	</div>
	
</div>
</div>

<?php  Loader::element('footer_required', array('disableTrackingCode' => true)); ?>
</body>
</html>
