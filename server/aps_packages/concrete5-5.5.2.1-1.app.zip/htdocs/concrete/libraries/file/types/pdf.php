<?php 

defined('C5_EXECUTE') or die("Access Denied.");

class PdfFileTypeInspector extends FileTypeInspector {

	public function inspect($fv) {
		
		/*
		$path = $fv->getPath();
		
		// create a level one and a level two thumbnail
		// load up image helper

		// Use image helper to create thumbnail at the right size
		$fv->createThumbnailDirectories();
		exec('/usr/local/bin/convert \'' . $fv->getPath() . '\'[0] -thumbnail ' . AL_THUMBNAIL_WIDTH . 'x' . AL_THUMBNAIL_HEIGHT . ' \'' . $fv->getThumbnailPath(1) . '\'');
		exec('/usr/local/bin/convert \'' . $fv->getPath() . '\'[0] -thumbnail ' . AL_THUMBNAIL_WIDTH_LEVEL2 . 'x' . AL_THUMBNAIL_HEIGHT_LEVEL2 . ' \'' . $fv->getThumbnailPath(2) . '\'');
		
		*/
		
	}
	

}