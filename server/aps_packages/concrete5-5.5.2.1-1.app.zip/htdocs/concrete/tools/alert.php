<?php   defined('C5_EXECUTE') or die("Access Denied.");
Loader::library('view');
?>

<div id="ccm-popup-alert" class="ccm-ui">
	<div id="ccm-popup-alert-message" class="alert-message block-message error"></div>
</div>
