<?php 
defined('C5_EXECUTE') or die("Access Denied.");
?>
<script type="text/javascript">
	ccm_launchFileManager('&fType=' + ccmi18n_filemanager.FTYPE_IMAGE);
</script>
